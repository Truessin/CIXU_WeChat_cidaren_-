"""Local publication check. Findings never include matched secret values."""
import ast
import json
from pathlib import Path
import re
import sys


def audit(root):
    findings = []
    count = 0
    patterns = {
        'api-key-format': r'sk-[A-Za-z0-9_-]{16,}',
        'jwt': r'eyJ[A-Za-z0-9_-]{12,}\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+',
        'private-key': r'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----',
        'personal-path': r'[A-Z]:[\\/]+Users[\\/]+[^\\/\s]+',
    }
    for path in sorted(root.rglob('*')):
        rel = path.relative_to(root)
        if any(p in {'.git', '.venv', '__pycache__', '.pytest_cache', 'build', 'dist', 'work'} for p in rel.parts):
            continue
        if not path.is_file():
            continue
        count += 1
        name = path.name.lower()
        if ('.capture' in rel.parts or 'diagnostics' in rel.parts or 'logs' in rel.parts
                or (name.startswith('.env') and not name.endswith('.example'))
                or name in {'secrets.json', 'credentials.json', 'service-account.json'}
                or path.suffix.lower() in {'.pem', '.key', '.pfx', '.p12', '.log'}):
            findings.append((rel.as_posix(), 0, 'private-file'))
        if path.suffix.lower() not in {'.py', '.json', '.md', '.txt', '.ps1', '.spec', '.yml', '.yaml', '.toml'}:
            continue
        text = path.read_text(encoding='utf-8', errors='replace')
        for kind, pattern in patterns.items():
            for match in re.finditer(pattern, text):
                findings.append((rel.as_posix(), text[:match.start()].count('\n') + 1, kind))
        if path.suffix.lower() == '.json':
            try:
                data = json.loads(text)
            except ValueError:
                findings.append((rel.as_posix(), 0, 'invalid-json'))
                continue
            if name in {'answer_lib.json', 'word_pool.json', 'verified_answers.json'} and data:
                findings.append((rel.as_posix(), 0, 'personal-learning-data'))
            def walk(value):
                if isinstance(value, dict):
                    for key, item in value.items():
                        if re.fullmatch(r'(?:api_key|key_protected|password|secret|private_key|database_url|access_token|usertoken|token|cookie)', key, re.I) and item:
                            findings.append((rel.as_posix(), 0, 'nonempty-sensitive-field'))
                        walk(item)
                elif isinstance(value, list):
                    for item in value:
                        walk(item)
            walk(data)
        if path.suffix.lower() == '.py' and 'tests' not in rel.parts:
            try:
                tree = ast.parse(text)
            except SyntaxError:
                findings.append((rel.as_posix(), 0, 'invalid-python'))
                continue
            for node in ast.walk(tree):
                if isinstance(node, ast.Assign) and isinstance(node.value, ast.Constant) and isinstance(node.value.value, str) and node.value.value:
                    if any(isinstance(t, ast.Name) and re.fullmatch(r'(?:api_key|password|private_key|access_token|usertoken|token|cookie|database_url)', t.id, re.I) for t in node.targets):
                        findings.append((rel.as_posix(), node.lineno, 'hardcoded-sensitive-assignment'))
    return count, findings


if __name__ == '__main__':
    root = Path(sys.argv[1] if len(sys.argv) > 1 else '.').resolve()
    count, findings = audit(root)
    print(json.dumps({'files_checked': count, 'findings': [{'file': p, 'line': n, 'category': c} for p, n, c in findings]}, ensure_ascii=False, indent=2))
    raise SystemExit(bool(findings))
