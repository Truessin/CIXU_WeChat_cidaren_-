# 来源与修改说明

本修改版名称：词序（CiXu）1.5，修改日期：2026-10-25。
基于 ularch / Easy_Cidaren 及该项目贡献者的代码；上游进一步基于 github123666/cidaren。
上游地址：https://github.com/ularch/Easy_Cidaren
基准提交：2ce37edca67fd04b183a2a550c9e71442c696dfb
代码继续按 GPL-3.0 提供；完整许可证见 LICENSE。保留上游 README 作为来源记录。
本程序不是上游官方发行版。修改包含新界面、查询及词形缓存、选项映射修复、已验证答案缓存、不确定答案策略和任务线程管理；详见 README.md。

英语模型 en_core_web_sm 3.8.0 来源：Explosion/spacy-models，MIT 许可；附带模型目录中的 LICENSE 与 LICENSES_SOURCES。
运行时包含 Python、PyQt6/Qt、spaCy 及依赖、Requests、Brotli 等第三方组件，权利及许可证归各自作者；依赖版本见 requirements.txt。
界面移除宣传性内容不表示消除上游著作权或改变开源许可。

1.1 增加内置 Token 获取、请求头/JSON/cURL 剪贴板导入、临时代理及证书恢复。获取后端使用 mitmproxy 12.2.0（MIT，https://github.com/mitmproxy/mitmproxy）；许可证见 THIRD-PARTY-LICENSES 目录。

1.2 增加释义与例句覆盖修复、DeepSeek/兼容模型 API 辅助、Windows 用户加密密钥配置、手动助手工作流和未解题诊断。个人 API 配置不属于源码包内容。

1.3 修复任务生命周期和界面交互：安全停止、任务切换排队、结束后控件恢复、取消加载、刷新保持选择。答题与模型逻辑沿用 1.2。

1.4 增加平滑滚动、日志合并更新、多选项目和顺序队列。

1.5 修复字符串/列表释义解析、括号义项边界、词性与否定处理、已知词形还原、例句填空匹配及缓存排版兼容性。默认关闭模型辅助，完整说明与验证范围见 README.md。

GitHub 发布整理（2026-10-25）：清空个人学习缓存，添加默认配置模板、忽略规则和本地发布扫描；移除响应原文日志与历史调试样例，增加日志脱敏；打包改为配置模板白名单。
