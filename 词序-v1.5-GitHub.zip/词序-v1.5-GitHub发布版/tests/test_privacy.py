import logging
from util.privacy import redact, register_secret, PrivacyFormatter


def test_private_fields_and_paths():
    for key in ('Usertoken', 'API_KEY', 'password', 'key_protected', 'topic_code', 'DATABASE_URL'):
        assert 'sensitive-value' not in redact('"%s": "sensitive-value"' % key)
    assert 'TestUser' not in redact('C:' + chr(92) + 'Users' + chr(92) + 'TestUser' + chr(92) + 'project')


def test_registered_secret_in_free_text_and_format_args():
    register_secret('synthetic-runtime-credential')
    record = logging.LogRecord('test', 20, '', 1, 'failed: %s', ('synthetic-runtime-credential',), None)
    assert 'synthetic-runtime-credential' not in PrivacyFormatter('%(message)s').format(record)


def test_non_sensitive_status_is_preserved():
    assert redact('请求成功 code=1；完成 3/20') == '请求成功 code=1；完成 3/20'
