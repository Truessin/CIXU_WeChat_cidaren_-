"""Offline integration check: no system proxy/CA changes and no upstream account request.
Run: python tests/check_capture.py [--app PATH_TO_CIXU_EXE] [--mode token|cancel]
"""
import argparse
from contextlib import ExitStack
import json
from pathlib import Path
import sys
from unittest.mock import patch
import requests

source=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(source))
from api.capture_client import CaptureClient


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--app'); parser.add_argument('--mode',choices=['token','cancel'],default='token')
    args=parser.parse_args()
    root=Path(args.app).resolve().parent if args.app else source
    seen=[]
    def event(e):
        seen.append(e)
        if e['event']=='error': print(e.get('message',''),flush=True)
        if e['event']=='ready':
            if args.mode=='cancel':
                client.stop(); return
            session=requests.Session(); session.trust_env=False
            reply=session.get('https://app.vocabgo.com/student/offline-test',
                headers={'usertoken':'offline-synthetic-token'},
                proxies={'https':f"http://127.0.0.1:{e['port']}"},
                verify=e['certificate'],timeout=10)
            assert reply.status_code==204
    client=CaptureClient(root,event,test=True)
    with ExitStack() as stack:
        if args.app:
            stack.enter_context(patch.object(sys,'frozen',True,create=True))
            stack.enter_context(patch.object(sys,'executable',str(Path(args.app).resolve())))
        client.run()
    assert any(e['event']=='done' and e['cleaned'] for e in seen),seen
    if args.mode=='token':
        assert any(e.get('token')=='offline-synthetic-token' for e in seen),seen
    else:
        assert not any(e['event']=='token' for e in seen),seen
    print(json.dumps({'passed':True,'mode':args.mode,'packaged':bool(args.app),
        'system_proxy_modified':False,'system_ca_store_modified':False,'synthetic_token_only':True}))

if __name__=='__main__': main()
