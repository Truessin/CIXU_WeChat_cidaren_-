import json
from copy import deepcopy
from types import SimpleNamespace
from unittest.mock import patch, MagicMock
import pytest

from util.select_mean import select_mean, select_match_word
from util import question_cache
from util import word_revert as lemma
from api import main_api
from answer_questions.answer_questions import together_word, _match_tips_words, jump_read, answer
from PyQt6.QtWidgets import QApplication
from view.clean_window import CleanWindow
from publicInfo.publicInfo import PublicInfo
from log.log import Log


def info(tmp_path, mode=15):
    return SimpleNamespace(path=str(tmp_path), exam={
        'topic_mode':mode, 'stem':{'content':'pack','remark':None},
        'options':[{'content':'noun 包；盒','answer_tag':8}, {'content':'verb 装箱','answer_tag':4}]},
        word_means=['verb 装箱'], word_list=['verb 装箱'], course_id='A', now_unit='B', is_self_built=False)


def test_matching_returns_actual_tag_not_reordered_index(tmp_path):
    assert select_mean(info(tmp_path)) == 4


def test_ambiguous_definition_declines(tmp_path):
    p=info(tmp_path); p.exam['options'].append({'content':'verb 装箱','answer_tag':10})
    assert select_mean(p) is None


def test_reject_character_anagram(tmp_path):
    p=info(tmp_path); p.word_means=['箱装']
    assert select_mean(p) is None


def test_unknown_definition_does_not_guess(tmp_path):
    p=info(tmp_path); p.word_means=['unmatched']
    assert select_mean(p) is None


def test_cache_remaps_shuffled_options_and_tags(tmp_path):
    p=info(tmp_path); question_cache.remember(p,4,True)
    p.exam['options'].reverse(); p.exam['options'][0]['answer_tag']=19
    assert question_cache.lookup(p) == 19


def test_cache_distinguishes_full_stem_and_choices(tmp_path):
    p=info(tmp_path); question_cache.remember(p,4,True)
    p.exam['stem']['content']='different sentence'
    assert question_cache.lookup(p) is None
    p.exam['stem']['content']='pack'; p.exam['options'][0]['content']='different option'
    assert question_cache.lookup(p) is None


def test_wrong_answer_invalidates_cache(tmp_path):
    p=info(tmp_path); question_cache.remember(p,4,True); question_cache.remember(p,4,False)
    assert question_cache.lookup(p) is None


def test_phrase_cache_keeps_order(tmp_path):
    p=info(tmp_path,32); question_cache.remember(p,'in,the,end',True)
    assert question_cache.lookup(p)=='in,the,end'


def test_multiselect_uses_original_option_tag(tmp_path):
    p=info(tmp_path,31); p.exam['stem']['remark']=[{'relation':'verb 装箱'}]
    assert together_word(p)=={'verb 装箱':4}


def test_spelling_rejects_ambiguous_prefix():
    assert _match_tips_words(['ca'],[3],['cat','car']) is None
    assert _match_tips_words(['ca'],[3],['cat','card'])==['cat']


def test_language_model_loaded_once():
    lemma._load_model.cache_clear(); lemma.word_revert.cache_clear()
    model=MagicMock(); model.return_value=[SimpleNamespace(lemma_='pack')]
    with patch.object(lemma.spacy,'load',return_value=model) as load:
        assert lemma.word_revert('packed')=='pack'
        assert lemma.word_revert('packing')=='pack'
        assert lemma.word_revert('packed')=='pack'
        assert load.call_count==1
        assert model.call_count==2
    lemma._load_model.cache_clear(); lemma.word_revert.cache_clear()


def test_word_query_cached_by_course_and_unit(tmp_path):
    p=info(tmp_path); response=MagicMock(); response.json.return_value={'code':1,'data':{},'jv':0}
    with patch.object(main_api,'check_jv_and_retry_get',return_value=response) as get, \
         patch.object(main_api,'handle_response'), patch.object(main_api,'debase64',return_value={'means':[]}):
        main_api.requests.rqs_session=MagicMock()
        main_api.query_word(p,'pack'); p.word_query_result['means'].append('mutation')
        main_api.query_word(p,'pack'); assert p.word_query_result=={'means':[]}
        assert get.call_count==1
        p.now_unit='C'; main_api.query_word(p,'pack'); assert get.call_count==2


def test_reading_last_card_completes_without_index_error(tmp_path):
    p=info(tmp_path,0)
    def complete(_): p.exam='complete'
    with patch('answer_questions.answer_questions.next_exam',side_effect=complete): jump_read(p)
    assert p.exam=='complete'


def test_unknown_audio_question_declines(tmp_path):
    assert answer(info(tmp_path,13),13) is None


def test_config_honors_short_intervals():
    p=PublicInfo('.')
    assert p.min_time==0.5 and p.max_time==1.0


def test_clean_window_renders_offline():
    app=QApplication.instance() or QApplication([])
    window=CleanWindow(PublicInfo('.'),'.',Log('test').logger,MagicMock())
    window.render_tasks([{'task_name':'示例任务','progress':25,'score':90}])
    assert window.task_list.rowCount()==1
    assert '免费' not in window.windowTitle()
    window.update_progress('8/20|6|1|1|1/1|示例任务')
    assert window.progress_bar.value()==8
    window.close()

def test_context_mean_uses_matched_example(tmp_path):
    p=info(tmp_path,11); p.exam['stem']['content']='Please {pack} a box.'
    p.word_list=['pack']
    data={'means':[
        {'mean':['noun','包；盒'],'usages':[{'examples':[{'sen_content':'This is a {pack}.'}]}]},
        {'mean':['verb','装箱'],'usages':[{'examples':[{'sen_content':'Please {pack} a box.'}]}]}]}
    with patch('answer_questions.answer_questions.query_word',side_effect=lambda info,word:setattr(info,'word_query_result',data)):
        assert answer(p,11)==4
        p.exam['stem']['content']='Unknown {pack} usage.'
        assert answer(p,11) is None


def test_unknown_pauses_without_retry():
    import main
    worker=main.TaskWorker([{'task_name':'offline'}])
    main.main=Log('worker_test')
    errors=[]; worker.task_error.connect(errors.append)
    with patch.object(worker,'complete_test',side_effect=main.UncertainAnswer('uncertain')) as complete:
        worker.run(); assert complete.call_count==1
    assert errors==['uncertain']


def test_security_verification_stops_without_retry():
    import main
    worker=main.TaskWorker([{'task_name':'offline'}]); main.main=Log('worker_test')
    errors=[]; worker.task_error.connect(errors.append)
    with patch.object(worker,'complete_test',side_effect=main.SecurityVerifyError('verification')) as complete:
        worker.run(); assert complete.call_count==1
    assert errors and 'verification' in errors[0]


def test_stop_interrupts_pending_interval():
    import main,time
    main.public_info=SimpleNamespace(min_time=10,max_time=10)
    worker=main.TaskWorker([]); worker.stop()
    start=time.monotonic(); worker._wait_between_questions()
    assert time.monotonic()-start<0.1


def test_model_real_lemma():
    lemma._load_model.cache_clear(); lemma.word_revert.cache_clear()
    assert lemma.word_revert('packed')=='pack'


def test_request_sessions_have_timeout_and_token():
    import api.request_header as headers
    headers.set_token('offline-test-token')
    with patch('requests.Session.request',return_value=MagicMock()) as request:
        headers.class_task_request.get('https://example.invalid')
        assert request.call_args.kwargs['timeout']==(5,20)
    assert headers.class_task_request.headers['Usertoken']=='offline-test-token'
    assert 'Content-Length' not in headers.rqs2_session.headers
