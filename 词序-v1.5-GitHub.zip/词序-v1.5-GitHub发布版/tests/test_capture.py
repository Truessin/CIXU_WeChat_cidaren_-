"""Capture tests never install certificates or modify the actual Windows proxy."""
from pathlib import Path
from unittest.mock import patch,MagicMock
import json
import pytest
from api.capture_client import token_from_text
from api.capture_helper import extract_token
from api import capture_system as system

@pytest.mark.parametrize('text',[
    'offline-test-token',
    'UserToken: offline-test-token\nAccept: */*',
    'curl https://app.vocabgo.com -H "usertoken: offline-test-token"',
    '{"headers":{"UserToken":"offline-test-token"}}',
])
def test_import_formats(text):
    assert token_from_text(text)=='offline-test-token'

@pytest.mark.parametrize('text',['', 'hello world', '{"password":"not-a-token"}', 'https://example.com'])
def test_import_rejects_unrelated_text(text):
    assert token_from_text(text) is None


def test_capture_is_scoped_to_exact_host():
    assert extract_token('app.vocabgo.com',{'usertoken':'synthetic-token'})=='synthetic-token'
    for host in ['example.com','app.vocabgo.com.evil.test','vocabgo.com']:
        assert extract_token(host,{'usertoken':'synthetic-token'}) is None
    assert extract_token('app.vocabgo.com',{'authorization':'secret'}) is None
    assert extract_token('app.vocabgo.com',{'usertoken':'token\nheader'}) is None


def make_manager(tmp_path, original):
    folder=tmp_path/'.capture'/'session-test'; folder.mkdir(parents=True)
    with patch.object(system,'read_settings',return_value=original):
        return system.SystemCapture(tmp_path,folder,18888)


def test_restore_exact_proxy_and_pac(tmp_path):
    original={'ProxyEnable':[1,4],'ProxyServer':['old:8080',1],
              'ProxyOverride':None,'AutoConfigURL':['https://pac.example/pac',1]}
    manager=make_manager(tmp_path,original)
    manager.data['changed']=list(system.FIELDS)
    current=manager.data['expected'].copy()
    with patch.object(system,'read_settings',return_value=current), \
         patch.object(system,'write_setting') as write,patch.object(system,'refresh'):
        manager.restore()
    restored={call.args[0]:call.args[1] for call in write.call_args_list}
    assert restored==original
    assert not manager.journal.exists()


def test_restore_preserves_other_program_proxy(tmp_path):
    original={name:None for name in system.FIELDS}; manager=make_manager(tmp_path,original)
    manager.data['changed']=list(system.FIELDS)
    current=manager.data['expected'].copy(); current['ProxyServer']=['new-vpn:9999',1]
    with patch.object(system,'read_settings',return_value=current),patch.object(system,'write_setting') as write:
        manager.restore(); write.assert_not_called()


def test_certificate_cleanup_idempotent(tmp_path):
    manager=make_manager(tmp_path,{name:None for name in system.FIELDS})
    manager.data['certificate']='a'*40
    with patch.object(system,'read_settings',return_value={}), \
         patch.object(system,'certificate_present',return_value=False),patch.object(system,'certutil') as cert:
        manager.restore(); cert.assert_not_called()
    assert manager.data['certificate'] is None


def test_certificate_failure_keeps_recovery_record(tmp_path):
    manager=make_manager(tmp_path,{name:None for name in system.FIELDS})
    manager.data['certificate']='a'*40; manager.save()
    with patch.object(system,'read_settings',return_value={}), \
         patch.object(system,'certificate_present',return_value=True), \
         patch.object(system,'certutil',side_effect=RuntimeError('mock permission failure')):
        with pytest.raises(RuntimeError): manager.restore()
    assert manager.journal.exists()
    assert 'token' not in manager.journal.read_text()


def test_two_capture_instances_do_not_overlap(tmp_path):
    with system.capture_lock(tmp_path):
        with pytest.raises(RuntimeError):
            with system.capture_lock(tmp_path): pass
    with system.capture_lock(tmp_path): pass


def test_capture_ui_offers_get_and_clipboard():
    from PyQt6.QtWidgets import QApplication
    from view.clean_window import CleanWindow
    from publicInfo.publicInfo import PublicInfo
    from log.log import Log
    app=QApplication.instance() or QApplication([])
    window=CleanWindow(PublicInfo('.'),'.',Log('test').logger,MagicMock())
    assert window.capture_button.text()=='获取 Token'
    with patch.object(window,'token_login') as connect:
        window.use_captured_token('offline-test-token')
        assert window.token_input.text()=='offline-test-token'
        connect.assert_called_once()
    window.close()
