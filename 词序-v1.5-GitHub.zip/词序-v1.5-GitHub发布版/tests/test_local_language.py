import json
from types import SimpleNamespace
from unittest.mock import patch

import pytest

from answer_questions.answer_questions import answer
from util import question_cache
from util.local_language import context_definitions, definition, plain, resolve_word
from util.select_mean import _unique_mean_option, handle_query_word_mean, word_examples


@pytest.mark.parametrize('raw', ['verb 投标；竞标；出价', ['verb', '投标；竞标；出价']])
def test_context_string_and_list_definitions_keep_part_of_speech(tmp_path, raw):
    exam = {'topic_mode':11, 'stem':{'content':'Their firm decided to {bid} on the guidance system.', 'remark':None},
            'options':[{'content':'noun 投标；出价','answer_tag':3},
                       {'content':'verb 竞标；投标；出价','answer_tag':9}]}
    data = {'means':[{'mean':raw,'usages':[{'examples':[{'sen_content':'Their  firm decided to {bid} on the guidance system.'}]}]}]}
    p = SimpleNamespace(path=str(tmp_path),exam=exam,word_list=['bid'],word_means=[],
                        word_query_result={},_assist_config={'mode':'off'})
    def query(info, word):
        assert word == 'bid'
        info.word_query_result = data
    with patch('answer_questions.answer_questions.query_word',side_effect=query), \
         patch('util.model_assist.ask_api',side_effect=AssertionError('No model API allowed')):
        assert answer(p,11) == 9


def test_all_definition_reader_preserves_parenthetical_boundaries():
    p=SimpleNamespace(word_query_result={'options':[{'content':{'mean':'verb 把…强加；（尤指上级）要求；（勉强）做事'}}]})
    handle_query_word_mean(p)
    assert p.word_means == ['verb 把...强加;(尤指上级)要求;(勉强)做事']
    assert _unique_mean_option([{'content':'verb 勉强做事；把…强加','answer_tag':12},
                                {'content':'verb 废除','answer_tag':5}],p.word_means) == 12


@pytest.mark.parametrize('actual,source',[
    ('noun 幕障','noun （雾、烟等）幕障'),
    ('noun 背弃；屈服','noun （对原则的）背弃；（向他人的）屈服'),
    ('n. 港口；避难所',['noun','港口；避难所']),
])
def test_usage_notes_and_definition_list_types(actual,source):
    assert _unique_mean_option([{'content':actual,'answer_tag':27}],[source]) == 27


def test_parts_of_speech_are_not_interchangeable():
    assert _unique_mean_option([{'content':'noun 投标；出价','answer_tag':1}],['verb 投标；出价']) is None


def test_negation_in_parenthesis_is_not_erased():
    assert definition('verb （不）支持')[1] == '不支持'
    assert _unique_mean_option([{'content':'verb 支持','answer_tag':1}],['verb （不）支持']) is None


def test_normalization_does_not_guess_anagrams_or_two_valid_senses():
    assert _unique_mean_option([{'content':'装箱','answer_tag':1}],['箱装']) is None
    assert _unique_mean_option([{'content':'港口','answer_tag':1},{'content':'避难所','answer_tag':2}],['noun 港口；避难所']) is None


@pytest.mark.parametrize('word,expected',[
    ('bidding','bid'),('running','run'),('studies','study'),('baked','bake'),
    ('PACKED','pack'),('new%20era','new era'),
])
def test_known_inflections_do_not_require_any_model(word,expected):
    known=['bid','run','study','bake','pack','new era']
    def forbidden(_):
        raise AssertionError('Known inflection must not call an NLP fallback')
    assert resolve_word(word,known,forbidden) == expected


def test_ambiguous_inflection_is_not_resolved_by_first_candidate():
    assert resolve_word('axes',['ax','axe'],lambda _: 'axes') == 'axes'


def test_context_html_and_percent_encoded_space():
    exam={'stem':{'content':'The <b>{veil}</b>%20of mist.','remark':None}}
    data={'means':[{'mean':['noun','幕障'],'usages':[{'examples':[{'sen_content':'The {veil} of mist.'}]}]}]}
    assert context_definitions(exam,data) == ['noun 幕障']


def test_example_blank_can_match_without_chinese_translation():
    p=SimpleNamespace(exam={'stem':{'content':'She has {} her bags.','remark':None}},word_list=['pack'],word_query_result={})
    def query(info,word):
        info.word_query_result={'means':[{'mean':['verb','收拾'],'usages':[{'examples':[{'sen_content':'She has {packed} her bags.'}]}]}]}
    with patch('util.select_mean.query_word',side_effect=query):
        assert word_examples(p,['pack']) == 'packed'


def test_conflicting_english_template_does_not_select_by_translation_alone():
    p=SimpleNamespace(exam={'stem':{'content':'He is not {}.','remark':'他是准备好的。'}},word_list=['ready'],word_query_result={})
    def query(info,word):
        info.word_query_result={'means':[{'mean':['adj','准备好的'],'usages':[{'examples':[{'sen_content':'He is {ready}.','sen_mean_cn':'他是准备好的。'}]}]}]}
    with patch('util.select_mean.query_word',side_effect=query):
        assert word_examples(p,['ready']) == ''


def test_verified_cache_ignores_formatting_but_keeps_new_option_tag(tmp_path):
    p=SimpleNamespace(path=str(tmp_path),exam={'topic_mode':22,'stem':{'content':'  pack  ','remark':None},
                'options':[{'content':'noun 包；盒','answer_tag':1},{'content':'verb 装箱','answer_tag':2}]})
    question_cache.remember(p,2,True)
    p.exam['stem']['content']='pack'
    p.exam['options'][1]={'content':'verb   装箱','answer_tag':19}
    assert question_cache.lookup(p) == 19


def test_old_verified_cache_still_works(tmp_path):
    p=SimpleNamespace(path=str(tmp_path),exam={'topic_mode':22,'stem':{'content':'pack','remark':None},
                 'options':[{'content':'verb 装箱','answer_tag':8}]})
    folder=tmp_path/'config';folder.mkdir()
    (folder/'verified_answers.json').write_text(json.dumps({question_cache.key_for(p.exam,normalized=False):{'kind':'option','value':'verb 装箱'}}),encoding='utf-8')
    assert question_cache.lookup(p) == 8
