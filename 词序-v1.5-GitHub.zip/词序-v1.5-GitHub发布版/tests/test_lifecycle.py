"""Real Qt-thread lifecycle tests; no platform or model network calls."""
import threading
import time
from unittest.mock import patch
import pytest
from PyQt6 import QtCore,QtWidgets
from view.clean_window import CleanWindow
from publicInfo.publicInfo import PublicInfo
from log.log import Log


def task(n,kind=1):
    return {'task_name':f'Course {n}','task_id':n,'release_id':n+100,'course_id':'test',
            'task_type':kind,'progress':0,'score':0}


class ControlledWorker(QtCore.QThread):
    task_finished=QtCore.pyqtSignal(str)
    task_completed=QtCore.pyqtSignal(object)
    task_error=QtCore.pyqtSignal(str)
    task_progress=QtCore.pyqtSignal(str)
    task_notice=QtCore.pyqtSignal(str)
    batch_finished=QtCore.pyqtSignal(str)
    assist_requested=QtCore.pyqtSignal(object)
    instances=[]
    def __init__(self,tasks,batch_mode=False):
        super().__init__(); self.tasks=tasks; self._is_running=True
        self.current_index=1; self.current_task_name=tasks[0]['task_name']
        self.entered=threading.Event(); self.release=threading.Event(); self.error=None
        self.instances.append(self)
    def run(self):
        self.entered.set(); self.release.wait(5)
        if self.error: self.task_error.emit(self.error)
        elif self._is_running:
            self.task_completed.emit({'task':dict(self.tasks[0])})
            self.task_finished.emit('done')
    def stop(self): self._is_running=False
    def request_manual(self,prompt): return None
    def resolve_manual(self,*args): pass


def spin(check,seconds=2):
    until=time.monotonic()+seconds
    while time.monotonic()<until:
        QtWidgets.QApplication.processEvents()
        if check(): return
        time.sleep(.002)
    raise AssertionError('Qt state did not settle')


@pytest.fixture
def ui():
    app=QtWidgets.QApplication.instance() or QtWidgets.QApplication([])
    ControlledWorker.instances=[]
    w=CleanWindow(PublicInfo('.'),'.',Log('lifecycle').logger,ControlledWorker)
    w.user_info.setText('offline test'); w.render_tasks([task(1),task(2)])
    yield w
    w._pending_start=None
    if w.task_worker:
        worker=w.task_worker; worker.stop(); worker.release.set(); worker.wait(2000)
        app.processEvents()
    for call in list(w._calls): call.wait(2000)
    app.processEvents(); w.close()


def select(w,row): w._select_task_row(row)


def test_complete_first_course_then_start_second(ui):
    select(ui,0); ui.start(); first=ui.task_worker
    spin(first.entered.is_set)
    assert ui.task_list.isEnabled() and ui.stop_task.isEnabled()
    first.release.set(); spin(lambda:ui.task_worker is None)
    assert ui.start_task.isEnabled() and ui.learn_task.isEnabled()
    assert not ui.stop_task.isEnabled()
    assert ui.task_list.item(0,2).text()=='100%'
    select(ui,1); ui.start()
    assert ui.task_worker is not None and ui.task_worker.tasks[0]['task_id']==2
    assert ui.progress_bar.value()==0


def test_switch_waits_for_old_worker_before_starting_new(ui):
    select(ui,0); ui.start(); first=ui.task_worker; spin(first.entered.is_set)
    select(ui,1); ui.start()
    assert ui.task_worker is first and not first._is_running
    assert len(ControlledWorker.instances)==1
    assert ui._pending_start[0][0]['task_id']==2
    first.release.set(); spin(lambda:ui.task_worker is not first)
    assert ui.task_worker.tasks[0]['task_id']==2
    assert len(ControlledWorker.instances)==2


def test_pending_switch_can_be_cancelled(ui):
    select(ui,0); ui.start(); first=ui.task_worker; spin(first.entered.is_set)
    select(ui,1); ui.start(); ui.stop_current_task()
    assert ui._pending_start is None
    first.release.set(); spin(lambda:ui.task_worker is None)
    assert len(ControlledWorker.instances)==1


def test_stop_returns_to_selectable_idle_state(ui):
    select(ui,0); ui.start(); first=ui.task_worker; spin(first.entered.is_set)
    ui.stop_current_task()
    assert ui.task_list.isEnabled() and not first._is_running
    first.release.set(); spin(lambda:ui.task_worker is None)
    select(ui,1); ui.start()
    assert ui.task_worker.tasks[0]['task_id']==2


def test_security_error_releases_controls(ui):
    select(ui,0); ui.start(); first=ui.task_worker; spin(first.entered.is_set)
    first.error='需安全验证'; first.release.set(); spin(lambda:ui.task_worker is None)
    assert ui.state.text()=='需安全验证'
    assert ui.start_task.isEnabled() and ui.refresh.isEnabled()
    select(ui,1); ui.start(); assert ui.task_worker.tasks[0]['task_id']==2


def test_stale_finish_cannot_clear_new_worker(ui):
    select(ui,0); ui.start(); first=ui.task_worker; spin(first.entered.is_set)
    first.release.set(); spin(lambda:ui.task_worker is None)
    select(ui,1); ui.start(); second=ui.task_worker
    ui.worker_finished(first)
    assert ui.task_worker is second


def test_active_category_switch_only_reads_cached_list(ui):
    ui._task_cache[2]=[task(3,2)]
    select(ui,0); ui.start(); first=ui.task_worker; spin(first.entered.is_set)
    with patch.object(ui,'call') as network:
        ui.test_task.click(); network.assert_not_called()
    assert ui.task_list.item(0,1).text()=='Course 3'
    ui._select_task_row(0); ui.start()
    first.release.set(); spin(lambda:ui.task_worker is not first)
    assert ui.task_worker.tasks[0]['task_id']==3


def test_select_and_queue_while_refresh_finishes(ui):
    gate=threading.Event(); called=[]
    ui.call(lambda:(gate.wait(2),[task(1)])[1],lambda value:called.append(value))
    assert ui._busy and ui.task_list.isEnabled()
    select(ui,1); ui.start(); gate.set()
    spin(lambda:ui.task_worker is not None)
    assert called==[] and ui.task_worker.tasks[0]['task_id']==2


def test_selection_survives_refresh(ui):
    select(ui,1); ui.render_tasks([task(2),task(1)])
    assert ui._selected_task()['task_id']==2


def test_finished_handler_recovers_even_if_dialog_cleanup_fails(ui):
    class Dialog:
        def reject(self): raise RuntimeError('widget already closed')
    select(ui,0); ui.start(); first=ui.task_worker; spin(first.entered.is_set)
    ui._manual_dialog=Dialog(); first.release.set(); spin(lambda:ui.task_worker is None)
    assert ui.start_task.isEnabled() and ui.refresh.isEnabled()
    ui._manual_dialog=None


def test_no_unused_score_request_blocks_completion():
    import main
    main.main=Log('worker_test')
    worker=main.TaskWorker([task(1)])
    finished=[]; worker.task_completed.connect(finished.append)
    with patch.object(worker,'complete_test'),patch.object(main,'get_task_score') as score:
        worker.run(); score.assert_not_called()
    assert finished[0]['task']['task_id']==1
