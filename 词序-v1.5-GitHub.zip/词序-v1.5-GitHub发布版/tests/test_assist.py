import json
from types import SimpleNamespace
from unittest.mock import MagicMock,patch
import pytest
from util.select_mean import _unique_mean_option,_sentence_norm
from util.model_assist import validate,snapshot,parse_result,ask_api,solve,record_unresolved,endpoint
from util.assist_config import save,load


def info(mode=22):
    return SimpleNamespace(exam={'topic_mode':mode,'stem':{'content':'harbor','remark':None},
        'options':[{'content':'noun 港口','answer_tag':12},{'content':'noun 山峰','answer_tag':8}],
        'answer_num':1,'w_lens':[],'w_tip':''},word_means=['noun 港口；避难所'])


def result(indices=None,words=None,confidence=.95):
    return {'choice_indices':indices or [],'words':words or [],'confidence':confidence,'uncertain':False}


def test_synonym_definition_reduces_unnecessary_skips():
    assert _unique_mean_option(info().exam['options'],['n.港口；避难所'])==12


def test_definition_punctuation_and_pos_normalized():
    assert _unique_mean_option([{'content':'adj. 快乐的','answer_tag':9}],['adjective 快乐的，愉快的'])==9


def test_never_match_negated_substring():
    assert _unique_mean_option([{'content':'不支持','answer_tag':1}],['支持']) is None


def test_two_synonym_candidates_remain_ambiguous():
    options=[{'content':'港口','answer_tag':1},{'content':'避难所','answer_tag':2}]
    assert _unique_mean_option(options,['noun 港口；避难所']) is None


def test_sentence_translation_punctuation_equivalent():
    assert _sentence_norm('他收拾好行李。')==_sentence_norm('他 收拾好行李！')


def test_model_selection_uses_actual_tag():
    assert validate(info(),result([0]))==12

@pytest.mark.parametrize('value',[
    result([99]),result([-1]),result([True]),result([0,1]),result([0],confidence=.4),
    {'choice_indices':[0],'confidence':.99,'uncertain':True},
    {'choice_indices':[0],'confidence':True,'uncertain':False},
])
def test_invalid_model_suggestions_declined(value):
    assert validate(info(),value) is None


def test_multiselect_count_and_tags():
    p=info(31); p.exam['answer_num']=2
    assert validate(p,result([0])) is None
    assert validate(p,result([0,0])) is None
    assert validate(p,result([0,1]))=={'0':12,'1':8}


def test_sub_options_are_flattened_and_tags_retained():
    p=info(43); p.exam['options']=[{'answer_tag':'1#','content':'run','sub_options':[{'content':'ran','answer_tag':2}]}]
    assert validate(p,result([0]))=='1#2'


def test_phrase_requires_correct_blank_count():
    p=info(32); p.exam['stem']['content']='_ _'
    assert validate(p,result([0])) is None
    assert validate(p,result([1,0]))=='noun 山峰,noun 港口'


def test_spelling_prefix_and_length_are_enforced():
    p=info(51); p.exam.update(w_tip='har',w_lens=[6])
    assert validate(p,result(words=['harbor']))=='harbor'
    assert validate(p,result(words=['harbors'])) is None
    assert validate(p,result(words=['parlor'])) is None


def test_multiblank_spelling_count_is_enforced():
    p=info(73); p.exam['stem']['content']='{gre} {ene}'; p.exam['w_lens']=[5,6]
    assert validate(p,result(words=['green','energy']))==json.dumps(['green','energy'])
    assert validate(p,result(words=['green'])) is None


def test_snapshot_omits_platform_credentials_and_topic_code():
    p=info(); p.usertoken='private-platform-token'; p.exam['topic_code']='private-code'
    text=json.dumps(snapshot(p))
    assert 'private-platform-token' not in text and 'private-code' not in text


def test_code_fenced_json_accepted():
    assert parse_result('```json\n{"uncertain":true}\n```')=={'uncertain':True}


def test_endpoint_has_no_redirect_or_insecure_remote_key_leak():
    assert endpoint('https://api.deepseek.com')=='https://api.deepseek.com/chat/completions'
    assert endpoint('https://ark.cn-beijing.volces.com/api/v3')=='https://ark.cn-beijing.volces.com/api/v3/chat/completions'
    with pytest.raises(ValueError): endpoint('http://remote.example')
    with pytest.raises(ValueError): endpoint('https://name:key@example.com')


def test_api_request_is_isolated_and_official_deepseek_format():
    transport=MagicMock(); response=transport.post.return_value; response.status_code=200
    response.json.return_value={'choices':[{'message':{'content':json.dumps(result([0]))}}]}
    config={'api_key':'fake-key','model':'deepseek-flash','base_url':'https://api.deepseek.com','timeout':12}
    value=ask_api(config,snapshot(info()),transport)
    assert value['choice_indices']==[0]
    request=transport.post.call_args
    assert request.kwargs['allow_redirects'] is False
    assert request.kwargs['json']['thinking']['type']=='disabled'
    assert request.kwargs['json']['max_tokens']==1024
    assert 'Usertoken' not in request.kwargs['headers']


def test_api_error_does_not_repeat_for_every_question():
    p=info(); p._assist_config={'mode':'api'}
    with patch('util.model_assist.ask_api',side_effect=ValueError('private-key must not leak')) as ask:
        assert solve(p) is None and solve(p) is None
        ask.assert_called_once()
    assert 'private-key' not in p._assist_status


def test_audio_without_content_not_sent_to_text_model():
    p=info(13); p._assist_config={'mode':'api'}
    with patch('util.model_assist.ask_api') as ask:
        assert solve(p) is None; ask.assert_not_called()


def test_manual_answer_validated_before_return():
    p=info(); p._assist_config={'mode':'manual','confidence':.8}; p._assist_callback=lambda prompt:result([0])
    assert solve(p)==12
    p._assist_callback=lambda prompt:result([900])
    assert solve(p) is None


def test_unresolved_diagnostics_is_scoped_and_has_reason(tmp_path):
    p=info(); p.path=str(tmp_path); p._assist_status='模型拒答'; p.exam['topic_code']='private-code'
    record_unresolved(p)
    content=(tmp_path/'diagnostics'/'unresolved.jsonl').read_text(encoding='utf-8')
    assert 'private-code' not in content and json.loads(content)['reason']=='模型拒答'


def test_key_persisted_as_dpapi_ciphertext(tmp_path):
    config={'mode':'api','base_url':'https://api.deepseek.com','model':'deepseek-flash','api_key':'not-a-real-api-key'}
    save(tmp_path,config)
    saved=(tmp_path/'config'/'model_assist.json').read_text()
    assert 'not-a-real-api-key' not in saved
    assert load(tmp_path)['api_key']=='not-a-real-api-key'


def test_stale_manual_response_cannot_answer_next_question():
    import main
    worker=main.TaskWorker([]); worker._manual_generation=2
    worker.resolve_manual(result([0]),generation=1)
    assert not worker._manual_ready.is_set()
    worker.resolve_manual(result([0]),generation=2)
    assert worker._manual_ready.is_set()
