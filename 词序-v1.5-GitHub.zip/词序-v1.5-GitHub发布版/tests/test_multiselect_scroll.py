from PyQt6 import QtCore, QtGui, QtWidgets
from test_lifecycle import ui, task, spin, ControlledWorker

# Keep one QApplication alive: recreating it invalidates Qt animation timers.
APP=QtWidgets.QApplication.instance() or QtWidgets.QApplication([])


def check(w,row):
    w.task_list.item(row,0).setCheckState(QtCore.Qt.CheckState.Checked)


def test_multiple_checks_launch_in_list_order(ui):
    check(ui,1); check(ui,0); ui.start()
    assert [t['task_id'] for t in ui.task_worker.tasks]==[1,2]
    assert len(ControlledWorker.instances)==1


def test_checks_survive_refresh_and_clear(ui):
    check(ui,1); ui.render_tasks([task(1),task(2),task(3)])
    assert [t['task_id'] for t in ui._checked_tasks()]==[2]
    ui.select_all_visible()
    assert len(ui._checked_tasks())==3
    ui.clear_checked(); assert ui._checked_tasks()==[]


def test_cross_category_selection_and_completed_test(ui):
    check(ui,0)
    ui.learn_task.setChecked(False); ui.test_task.setChecked(True)
    done=task(4,2); done['progress']=100
    ui.render_tasks([task(3,2),done]); ui.select_all_visible()
    assert [t['task_id'] for t in ui._checked_tasks()]==[1,3]
    assert not ui.task_list.item(1,0).flags() & QtCore.Qt.ItemFlag.ItemIsEnabled
    ui.start(); assert len(ui.task_worker.tasks)==2


def test_completed_item_unchecks_without_mutating_running_queue(ui):
    ui.select_all_visible(); ui.start()
    ui.on_task_completed({'task':task(1)})
    assert [t['task_id'] for t in ui._checked_tasks()]==[2]
    assert [t['task_id'] for t in ui.task_worker.tasks]==[1,2]


def test_switch_to_multiple_tasks_waits_for_stop(ui):
    ui.render_tasks([task(1),task(2),task(3)])
    check(ui,0); ui.start(); first=ui.task_worker; spin(first.entered.is_set)
    ui.clear_checked(); check(ui,1); check(ui,2); ui.start()
    assert ui.task_worker is first and not first._is_running
    first.release.set(); spin(lambda:ui.task_worker is not first)
    assert [t['task_id'] for t in ui.task_worker.tasks]==[2,3]


def test_wheel_accumulates_and_finishes_within_scroll_range(ui):
    ui.show(); ui.render_tasks([task(n) for n in range(150)])
    QtWidgets.QApplication.processEvents()
    bar=ui.task_list.verticalScrollBar(); assert bar.maximum()>0
    for _ in range(3):
        event=QtGui.QWheelEvent(QtCore.QPointF(20,20),QtCore.QPointF(20,20),QtCore.QPoint(),QtCore.QPoint(0,-120),QtCore.Qt.MouseButton.NoButton,QtCore.Qt.KeyboardModifier.NoModifier,QtCore.Qt.ScrollPhase.NoScrollPhase,False)
        QtWidgets.QApplication.sendEvent(ui.task_list.viewport(),event)
    assert bar.value()==0
    spin(lambda:ui._smooth_tasks.animations['vertical'].state()==QtCore.QAbstractAnimation.State.Stopped)
    assert bar.value()==min(bar.maximum(),3*28*QtWidgets.QApplication.wheelScrollLines())


def test_reading_old_logs_preserves_position(ui):
    ui.show()
    for i in range(200): ui.update_output_info(f'line {i}')
    ui._flush_log(); QtWidgets.QApplication.processEvents(); ui._smooth_log.stop()
    bar=ui.output_info.verticalScrollBar(); assert bar.maximum()>0
    bar.setValue(0); ui._pause_log_follow()
    ui.update_output_info('new line'); ui._flush_log()
    assert bar.value()==0 and ui._log_follow_paused
    ui.go_to_latest()
    spin(lambda:bar.value()==bar.maximum())
    assert not ui._log_follow_paused

def test_worker_executes_selected_tasks_in_order():
    from unittest.mock import patch
    import main
    from log.log import Log
    main.main=Log('batch_order')
    worker=main.TaskWorker([task(1),task(2),task(3)],batch_mode=True)
    seen=[]; completed=[]
    worker.task_completed.connect(lambda p:completed.append(p['task']['task_id']))
    with patch.object(worker,'complete_test',side_effect=lambda t:seen.append(t['task_id'])):
        worker.run()
    assert seen==completed==[1,2,3]


def test_worker_stop_does_not_start_remaining_selection():
    from unittest.mock import patch
    import main
    from log.log import Log
    main.main=Log('batch_stop')
    worker=main.TaskWorker([task(1),task(2)],batch_mode=True)
    seen=[]
    def finish_first(t):
        seen.append(t['task_id']); worker.stop()
    with patch.object(worker,'complete_test',side_effect=finish_first): worker.run()
    assert seen==[1]
