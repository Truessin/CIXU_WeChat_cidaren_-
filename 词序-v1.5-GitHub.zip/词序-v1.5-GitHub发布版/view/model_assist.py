"""Model settings and explicit copy/paste assistance dialogs."""
import json
from PyQt6 import QtCore,QtWidgets
from util.assist_config import load,save
from util.model_assist import ask_api,validate,parse_result


class ModelSettings(QtWidgets.QDialog):
    def __init__(self,root,parent=None):
        super().__init__(parent); self.root=root; self.setWindowTitle('模型辅助'); self.resize(640,510)
        self.config=load(root); self.testing=None
        form=QtWidgets.QFormLayout(self); form.setSpacing(12)
        intro=QtWidgets.QLabel('优先使用本地题库和词典，仅在无法确定时请求模型。模型建议经过选项、数量和拼写检查后，仍以平台判分为准。')
        intro.setWordWrap(True); form.addRow(intro)
        self.mode=QtWidgets.QComboBox(); self.mode.addItems(['关闭','API 自动辅助','手动使用电脑上的豆包/其他助手'])
        self.mode.setCurrentIndex({'off':0,'api':1,'manual':2}.get(self.config.get('mode'),0)); form.addRow('辅助方式',self.mode)
        presets=QtWidgets.QComboBox(); presets.addItems(['自定义接口','DeepSeek 官方','豆包 / 火山方舟'])
        form.addRow('接口预设',presets)
        self.url=QtWidgets.QLineEdit(self.config['base_url']); form.addRow('API 地址',self.url)
        self.model=QtWidgets.QLineEdit(self.config.get('model','')); self.model.setPlaceholderText('模型 ID 或推理接入点 ID'); form.addRow('模型',self.model)
        self.key=QtWidgets.QLineEdit(self.config.get('api_key','')); self.key.setEchoMode(QtWidgets.QLineEdit.EchoMode.Password); form.addRow('API Key',self.key)
        self.confidence=QtWidgets.QDoubleSpinBox(); self.confidence.setRange(0.5,1.0); self.confidence.setSingleStep(0.05); self.confidence.setValue(self.config.get('confidence',0.8)); form.addRow('模型自报置信度下限',self.confidence)
        self.timeout=QtWidgets.QSpinBox(); self.timeout.setRange(5,90); self.timeout.setSuffix(' 秒'); self.timeout.setValue(self.config.get('timeout',30)); form.addRow('请求超时',self.timeout)
        note=QtWidgets.QLabel('API 仅接收当前题干、选项和相关释义，不发送微信 Token 或账号资料；调用可能按量计费。Key 用 Windows 当前用户加密保存在本机，不能随源码压缩包分发。自报置信度不是经过校准的正确率。')
        note.setWordWrap(True); note.setStyleSheet('color:#68768b;'); form.addRow(note)
        self.status=QtWidgets.QLabel(''); self.status.setWordWrap(True); form.addRow(self.status)
        self.test=QtWidgets.QPushButton('测试接口（调用一道示例题）'); self.test.clicked.connect(self.test_connection); form.addRow(self.test)
        buttons=QtWidgets.QDialogButtonBox(QtWidgets.QDialogButtonBox.StandardButton.Save|QtWidgets.QDialogButtonBox.StandardButton.Cancel)
        buttons.accepted.connect(self.save_settings); buttons.rejected.connect(self.reject); form.addRow(buttons)
        self.buttons=buttons
        def preset(index):
            if index==1: self.url.setText('https://api.deepseek.com'); self.model.setText('deepseek-flash')
            elif index==2: self.url.setText('https://ark.cn-beijing.volces.com/api/v3'); self.model.clear()
        presets.currentIndexChanged.connect(preset)

    def values(self):
        return {'mode':['off','api','manual'][self.mode.currentIndex()], 'base_url':self.url.text().strip(),
            'model':self.model.text().strip(),'api_key':self.key.text().strip(),
            'confidence':self.confidence.value(),'timeout':self.timeout.value()}

    def save_settings(self):
        try: save(self.root,self.values())
        except Exception: self.status.setText('保存失败，请检查配置与 Windows 用户加密权限。'); return
        self.accept()

    def test_connection(self):
        from view.clean_window import CallThread
        config=self.values()
        payload={'topic_mode':22,'stem':{'content':'apple','remark':None},
            'candidates':[{'id':0,'content':'noun 苹果'},{'id':1,'content':'noun 石头'}],'expected_count':1}
        self.test.setEnabled(False); self.buttons.setEnabled(False); self.status.setText('正在测试接口…')
        worker=self.testing=CallThread(lambda:ask_api(config,payload),self)
        def result(value):
            self.status.setText('连接成功，示例题回答正确。' if value.get('choice_indices')==[0] and not value.get('uncertain',True) else '已连接，但示例题答案不符合预期，请检查模型。')
        worker.result.connect(result)
        worker.error.connect(lambda text:self.status.setText('接口测试失败，请检查地址、Key、模型权限或网络。'))
        def finished():
            self.test.setEnabled(True); self.buttons.setEnabled(True); self.testing=None; worker.deleteLater()
        worker.finished.connect(finished); worker.start()

    def reject(self):
        if self.testing and self.testing.isRunning(): return
        super().reject()

    def closeEvent(self,event):
        if self.testing and self.testing.isRunning(): event.ignore()
        else: event.accept()


class ManualQuestion(QtWidgets.QDialog):
    resolved=QtCore.pyqtSignal(object)
    def __init__(self,prompt,parent=None):
        super().__init__(parent); self.setWindowTitle('等待模型辅助答案'); self.resize(720,540)
        self.prompt=prompt
        layout=QtWidgets.QVBoxLayout(self)
        label=QtWidgets.QLabel('复制题目到电脑上的豆包，取得 JSON 答案后粘贴到下方。音频或图片题还需在微信中查看原题。'); label.setWordWrap(True); layout.addWidget(label)
        question=QtWidgets.QPlainTextEdit(); question.setReadOnly(True); question.setPlainText(prompt); layout.addWidget(question)
        copy=QtWidgets.QPushButton('复制题目与格式要求'); copy.clicked.connect(lambda:QtWidgets.QApplication.clipboard().setText(prompt)); layout.addWidget(copy)
        self.answer=QtWidgets.QPlainTextEdit(); self.answer.setPlaceholderText('在此粘贴模型返回的 JSON 答案'); self.answer.setMaximumHeight(130); layout.addWidget(self.answer)
        row=QtWidgets.QHBoxLayout(); paste=QtWidgets.QPushButton('粘贴答案'); paste.clicked.connect(lambda:self.answer.setPlainText(QtWidgets.QApplication.clipboard().text())); row.addWidget(paste)
        use=QtWidgets.QPushButton('校验并继续'); use.clicked.connect(self.use); row.addWidget(use)
        skip=QtWidgets.QPushButton('本题放弃辅助'); skip.clicked.connect(self.reject); row.addWidget(skip); layout.addLayout(row)
        self.status=QtWidgets.QLabel('最多等待 3 分钟；超时后按未知答案策略处理。'); self.status.setWordWrap(True); layout.addWidget(self.status)

    def use(self):
        try: result=parse_result(self.answer.toPlainText())
        except (ValueError,TypeError): self.status.setText('没有识别到 JSON，请完整复制模型的 JSON 答案。'); return
        self.resolved.emit(result); self.accept()

    def reject(self):
        self.resolved.emit(None); super().reject()
