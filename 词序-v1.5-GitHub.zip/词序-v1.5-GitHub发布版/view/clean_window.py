"""Clean desktop UI for the local fork; upstream GPL attribution is in NOTICES.md."""
import json
import os
import threading
from PyQt6 import QtCore, QtWidgets, QtGui
from PyQt6.QtCore import Qt, QThread, pyqtSignal
from PyQt6.QtWidgets import QMessageBox
from api.login import verify_token
from api.main_api import get_class_task
from publicInfo.publicInfo import PublicInfo
from util.basic_util import get_all_task
from view.smooth_scroll import SmoothScroller


class CallThread(QThread):
    result = pyqtSignal(object)
    error = pyqtSignal(str)

    def __init__(self, function, parent):
        super().__init__(parent)
        self.function = function

    def run(self):
        try:
            self.result.emit(self.function())
        except Exception as exc:
            self.error.emit(str(exc))


class CleanWindow(QtWidgets.QMainWindow):
    def __init__(self, public_info, root_path, main_logger, task_worker_class):
        super().__init__()
        self.public_info = public_info
        self.root_path = root_path
        self.main_logger = main_logger
        self.task_worker_class = task_worker_class
        self.task_worker = None
        self._batch_mode = False
        self.token = ''
        self.setupUi(self)

    def setupUi(self, window):
        self._calls = []
        self._busy = False
        self._outcome = ''
        self._pending_start = None
        self._stop_requested = False
        self._call_cancel = threading.Event()
        self._task_cache = {1: [], 2: []}
        self._visible_tasks = []
        self._active_tasks = []
        self._checked_task_keys = set()
        self._pending_log_lines = []
        self._log_follow_paused = False
        self._log_updating = False
        self._log_timer = QtCore.QTimer(self)
        self._log_timer.setSingleShot(True); self._log_timer.setInterval(40)
        self._log_timer.timeout.connect(self._flush_log)
        self.setWindowTitle('词序 · 任务工作台')
        self.resize(1120, 820)
        self.setMinimumSize(920, 520)
        self.setStyleSheet('''
            QMainWindow { background:#f3f5f8; }
            QWidget { font-family:"Microsoft YaHei UI"; font-size:13px; color:#253044; }
            QFrame#card { background:white; border:1px solid #e2e7ee; border-radius:14px; }
            QLabel#brand { font-size:27px; font-weight:700; color:#172a42; }
            QLabel#muted { color:#758196; font-size:12px; }
            QLabel#heading { font-size:16px; font-weight:600; }
            QLabel#status { color:#247269; background:#e5f4ee; border-radius:10px; padding:7px 12px; }
            QLineEdit, QDoubleSpinBox, QComboBox { background:#fafbfd; border:1px solid #dce3ec; border-radius:7px; padding:9px; }
            QLineEdit:focus { border-color:#287c72; }
            QPushButton { background:white; border:1px solid #dce3ec; border-radius:7px; padding:9px 16px; }
            QPushButton:hover { background:#edf5f2; border-color:#91bdb0; }
            QPushButton#primary { background:#24776c; color:white; border:none; }
            QPushButton#primary:hover { background:#1a6158; }
            QPushButton#stop { color:#b34b4b; }
            QPushButton:disabled { color:#a4adba; background:#f1f3f6; border-color:#e6e9ee; }
            QRadioButton { padding:5px; spacing:7px; }
            QTableWidget { background:white; border:none; gridline-color:#edf0f5; selection-background-color:#e2f1ec; selection-color:#20372f; }
            QHeaderView::section { background:#f8fafc; border:none; padding:12px; color:#798599; font-size:12px; }
            QTextBrowser { background:#f8fafc; border:1px solid #edf0f5; border-radius:8px; padding:8px; font-family:Consolas,"Microsoft YaHei UI"; }
            QProgressBar { border:none; border-radius:5px; background:#e8edf1; height:10px; text-align:center; }
            QProgressBar::chunk { background:#398e7a; border-radius:5px; }
            QSplitter::handle { background:transparent; height:10px; }
            QScrollArea { background:transparent; border:none; }
            QScrollBar:vertical { background:#f0f3f6; width:10px; margin:0; }
            QScrollBar::handle:vertical { background:#c0cbd2; border-radius:5px; min-height:36px; }
            QScrollBar::handle:vertical:hover { background:#81aaa1; }
            QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height:0; }
            QScrollBar:horizontal { background:#f0f3f6; height:10px; margin:0; }
            QScrollBar::handle:horizontal { background:#c0cbd2; border-radius:5px; min-width:36px; }
            QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal { width:0; }
            QScrollBar::add-page, QScrollBar::sub-page { background:transparent; }
        ''')
        root = QtWidgets.QWidget()
        self.page_scroll = QtWidgets.QScrollArea()
        self.page_scroll.setWidgetResizable(True)
        self.page_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.page_scroll.setWidget(root)
        self.setCentralWidget(self.page_scroll)
        self._smooth_page = SmoothScroller(self.page_scroll,32)
        layout = QtWidgets.QVBoxLayout(root)
        layout.setContentsMargins(30, 24, 30, 24)
        layout.setSpacing(16)
        header = QtWidgets.QHBoxLayout()
        titles = QtWidgets.QVBoxLayout()
        brand = QtWidgets.QLabel('词序  /  任务工作台'); brand.setObjectName('brand')
        sub = QtWidgets.QLabel('连接账号，选择任务，查看每一步进度。'); sub.setObjectName('muted')
        titles.addWidget(brand); titles.addWidget(sub)
        header.addLayout(titles); header.addStretch()
        self.state = QtWidgets.QLabel('等待连接'); self.state.setObjectName('status'); self.state.setMaximumHeight(38); header.addWidget(self.state)
        self.model_button = QtWidgets.QPushButton('模型辅助'); self.model_button.clicked.connect(self.show_model_settings); header.addWidget(self.model_button)
        self.settings_button = QtWidgets.QPushButton('运行设置'); self.settings_button.clicked.connect(self.show_settings); header.addWidget(self.settings_button)
        about = QtWidgets.QPushButton('关于'); about.clicked.connect(self.show_about); header.addWidget(about)
        layout.addLayout(header)

        card, content = self.card()
        row = QtWidgets.QHBoxLayout()
        self.token_input = QtWidgets.QLineEdit(); self.token_input.setEchoMode(QtWidgets.QLineEdit.EchoMode.Password)
        self.token_input.setPlaceholderText('点击获取 Token，或在此粘贴已有 Token')
        self.login = QtWidgets.QPushButton('连接账号'); self.login.setObjectName('primary'); self.login.clicked.connect(self.token_login)
        self.capture_button = QtWidgets.QPushButton('获取 Token'); self.capture_button.setObjectName('primary'); self.capture_button.clicked.connect(self.get_token)
        self.paste_button = QtWidgets.QPushButton('从剪贴板导入'); self.paste_button.clicked.connect(self.import_token)
        row.addWidget(self.token_input, 1); row.addWidget(self.capture_button); row.addWidget(self.paste_button); row.addWidget(self.login); content.addLayout(row)
        self.user_info = QtWidgets.QLabel('未获取'); self.user_info.setWordWrap(True); content.addWidget(self.user_info)
        self.warn_info = QtWidgets.QLabel('首次使用可点击“获取 Token”；成功后自动填入并连接。'); self.warn_info.setObjectName('muted'); self.warn_info.setWordWrap(True); content.addWidget(self.warn_info)
        layout.addWidget(card)

        split = QtWidgets.QSplitter(Qt.Orientation.Vertical)
        split.setChildrenCollapsible(False)
        card, content = self.card()
        row = QtWidgets.QHBoxLayout()
        title = QtWidgets.QLabel('任务列表'); title.setObjectName('heading'); row.addWidget(title); row.addStretch()
        self.learn_task = QtWidgets.QRadioButton('学习任务'); self.learn_task.setChecked(True)
        self.test_task = QtWidgets.QRadioButton('测试任务')
        group = QtWidgets.QButtonGroup(self); group.addButton(self.learn_task); group.addButton(self.test_task)
        for radio in (self.learn_task, self.test_task):
            radio.clicked.connect(self.get_task_list); row.addWidget(radio)
        self.refresh = QtWidgets.QPushButton('刷新'); self.refresh.clicked.connect(self.get_task_list); row.addWidget(self.refresh)
        content.addLayout(row)
        selection_bar = QtWidgets.QHBoxLayout()
        self.select_all = QtWidgets.QPushButton('全选当前列表'); self.select_all.clicked.connect(self.select_all_visible)
        self.clear_selection = QtWidgets.QPushButton('清空勾选'); self.clear_selection.clicked.connect(self.clear_checked)
        selection_bar.addWidget(self.select_all); selection_bar.addWidget(self.clear_selection); selection_bar.addStretch()
        self.selection_count = QtWidgets.QLabel('已勾选 0 项'); self.selection_count.setObjectName('muted'); selection_bar.addWidget(self.selection_count)
        content.addLayout(selection_bar)
        self.task_list = QtWidgets.QTableWidget(0, 4)
        self.task_list.setHorizontalHeaderLabels(['勾选', '任务名称', '进度', '分数'])
        self.task_list.setEditTriggers(QtWidgets.QAbstractItemView.EditTrigger.NoEditTriggers)
        self.task_list.setSelectionBehavior(QtWidgets.QAbstractItemView.SelectionBehavior.SelectRows)
        self.task_list.setSelectionMode(QtWidgets.QAbstractItemView.SelectionMode.SingleSelection)
        self.task_list.verticalHeader().hide()
        self.task_list.verticalHeader().setDefaultSectionSize(46)
        self.task_list.horizontalHeader().setSectionResizeMode(1, QtWidgets.QHeaderView.ResizeMode.Stretch)
        self.task_list.setColumnWidth(0, 60); self.task_list.setColumnWidth(2, 100); self.task_list.setColumnWidth(3, 100)
        self.task_list.setVerticalScrollMode(QtWidgets.QAbstractItemView.ScrollMode.ScrollPerPixel)
        self.task_list.setHorizontalScrollMode(QtWidgets.QAbstractItemView.ScrollMode.ScrollPerPixel)
        self._smooth_tasks = SmoothScroller(self.task_list,28)
        self.task_list.itemChanged.connect(self._on_task_check_changed)
        self.task_list.itemClicked.connect(self._on_task_item_clicked)
        content.addWidget(self.task_list)
        self.empty = QtWidgets.QLabel('连接账号后，这里会显示可用任务。'); self.empty.setObjectName('muted'); content.addWidget(self.empty)
        row = QtWidgets.QHBoxLayout()
        self.start_task = QtWidgets.QPushButton('开始所选任务'); self.start_task.setObjectName('primary'); self.start_task.clicked.connect(self.start)
        self.batch_start = QtWidgets.QPushButton('执行未完成任务'); self.batch_start.clicked.connect(self.start_batch)
        self.stop_task = QtWidgets.QPushButton('停止'); self.stop_task.setObjectName('stop'); self.stop_task.setEnabled(False); self.stop_task.clicked.connect(self.stop_current_task)
        for b in (self.start_task, self.batch_start, self.stop_task): row.addWidget(b)
        row.addStretch(); content.addLayout(row)
        split.addWidget(card)

        card, content = self.card()
        row = QtWidgets.QHBoxLayout()
        self.progress_task_label = QtWidgets.QLabel('运行记录'); self.progress_task_label.setObjectName('heading'); row.addWidget(self.progress_task_label, 1)
        self.follow_output = QtWidgets.QCheckBox('自动滚动'); self.follow_output.setChecked(True); self.follow_output.toggled.connect(self._follow_toggled); row.addWidget(self.follow_output)
        self.latest_button = QtWidgets.QPushButton('回到最新'); self.latest_button.clicked.connect(self.go_to_latest); row.addWidget(self.latest_button); content.addLayout(row)
        row = QtWidgets.QHBoxLayout()
        self.progress_bar = QtWidgets.QProgressBar(); self.progress_bar.setTextVisible(False); self.progress_bar.setValue(0); row.addWidget(self.progress_bar, 1)
        for name, text in [('progress_label','0 / 0'),('progress_right_label','正确 0'),('progress_wrong_label','错误 0'),('progress_skip_label','跳过 0')]:
            label = QtWidgets.QLabel(text); setattr(self, name, label); row.addWidget(label)
        content.addLayout(row)
        self.output_info = QtWidgets.QTextBrowser(); self.output_info.document().setMaximumBlockCount(600)
        self._smooth_log = SmoothScroller(self.output_info,22)
        self._smooth_log.user_scrolled.connect(self._log_user_scroll)
        self._smooth_log.settled.connect(self._resume_log_at_bottom)
        self.output_info.verticalScrollBar().sliderPressed.connect(self._pause_log_follow)
        self.output_info.verticalScrollBar().sliderReleased.connect(self._resume_log_at_bottom)
        self.output_info.verticalScrollBar().valueChanged.connect(self._resume_log_at_bottom)
        content.addWidget(self.output_info)
        split.addWidget(card); split.setSizes([300, 210]); layout.addWidget(split, 1)
        foot = QtWidgets.QLabel('词序 1.5  ·  本地题库与例句优先  ·  无需 DeepSeek API 也可作答  ·  未解题自动记录')
        foot.setObjectName('muted'); layout.addWidget(foot)
        # These menus are retained for the inherited UI state helper only.
        self.menu = QtWidgets.QMenu(self); self.menu_2 = QtWidgets.QMenu(self)
        self.update_output_info('就绪。请连接账号。')
        self._sync_controls()

    def card(self):
        widget = QtWidgets.QFrame(); widget.setObjectName('card')
        box = QtWidgets.QVBoxLayout(widget); box.setContentsMargins(20, 16, 20, 16); box.setSpacing(12)
        return widget, box

    def update_output_info(self, info):
        self._pending_log_lines.append(str(info))
        if not self._log_timer.isActive(): self._log_timer.start()

    def _flush_log(self):
        if not self._pending_log_lines: return
        lines=self._pending_log_lines; self._pending_log_lines=[]
        bar=self.output_info.verticalScrollBar(); old=bar.value()
        follow=self.follow_output.isChecked() and not self._log_follow_paused
        self._log_updating=True
        try:
            cursor=QtGui.QTextCursor(self.output_info.document())
            cursor.movePosition(QtGui.QTextCursor.MoveOperation.End)
            cursor.beginEditBlock()
            prefix='\n' if not self.output_info.document().isEmpty() else ''
            cursor.insertText(prefix+'\n'.join(lines)); cursor.endEditBlock()
            self.output_info.document().documentLayout().documentSize()
            if not follow: bar.setValue(min(old,bar.maximum()))
        finally: self._log_updating=False
        if follow: self._smooth_log.scroll_to(bar.maximum(),duration=100)

    def _pause_log_follow(self):
        self._log_follow_paused=True

    def _log_user_scroll(self,direction):
        if direction>0: self._pause_log_follow()

    def _resume_log_at_bottom(self,*args):
        if self._log_updating: return
        bar=self.output_info.verticalScrollBar()
        if bar.value()==bar.maximum(): self._log_follow_paused=False

    def _follow_toggled(self,enabled):
        if not hasattr(self,'_smooth_log'): return
        if enabled: self.go_to_latest()
        else: self._smooth_log.stop()

    def go_to_latest(self):
        self._log_follow_paused=False
        self.follow_output.blockSignals(True); self.follow_output.setChecked(True); self.follow_output.blockSignals(False)
        self._flush_log()
        self.output_info.document().documentLayout().documentSize()
        self._smooth_log.scroll_to(self.output_info.verticalScrollBar().maximum(),duration=130)

    def _task_key(self, task):
        return tuple(str(task.get(k,'')) for k in ('course_id','task_id','release_id','task_name'))

    def _selected_task(self):
        item = self.task_list.item(self.task_list.currentRow(), 1)
        return item.data(Qt.ItemDataRole.UserRole) if item else None

    def _can_run(self,task):
        kind=task.get('task_type',1 if self.learn_task.isChecked() else 2)
        return not(kind==2 and task.get('progress',0)>=100)

    def _checked_tasks(self):
        selected=[]; seen=set()
        for kind in (1,2):
            for task in self._task_cache.get(kind,[]):
                key=self._task_key(task)
                if key in self._checked_task_keys and key not in seen and self._can_run(task):
                    selected.append(dict(task)); seen.add(key)
        return selected

    def _update_selection_status(self):
        count=len(self._checked_tasks())
        visible=sum(self._task_key(task) in self._checked_task_keys for task in self._visible_tasks)
        extra=f'（含其他类别 {count-visible} 项）' if count>visible else ''
        self.selection_count.setText(f'已勾选 {count} 项'+extra)
        self._sync_controls()

    def _on_task_check_changed(self,item):
        if item.column()!=0: return
        task=item.data(Qt.ItemDataRole.UserRole)
        if not task: return
        key=self._task_key(task)
        if item.checkState()==Qt.CheckState.Checked and self._can_run(task): self._checked_task_keys.add(key)
        else: self._checked_task_keys.discard(key)
        self._update_selection_status()

    def _refresh_checkboxes(self):
        blocker=QtCore.QSignalBlocker(self.task_list)
        for row,task in enumerate(self._visible_tasks):
            item=self.task_list.item(row,0)
            if item: item.setCheckState(Qt.CheckState.Checked if self._task_key(task) in self._checked_task_keys else Qt.CheckState.Unchecked)
        del blocker
        self._update_selection_status()

    def select_all_visible(self):
        self._checked_task_keys.update(self._task_key(task) for task in self._visible_tasks if self._can_run(task))
        self._refresh_checkboxes()

    def clear_checked(self):
        self._checked_task_keys.clear(); self._refresh_checkboxes()

    def _sync_controls(self):
        # Keep selection available until the worker's finished signal has been processed.
        active = self.task_worker is not None
        idle = not active and not self._busy
        for widget in (self.token_input,self.login,self.settings_button,self.capture_button,
                       self.paste_button,self.model_button):
            widget.setEnabled(idle)
        self.task_list.setEnabled(True)
        self.learn_task.setEnabled(not self._busy)
        self.test_task.setEnabled(not self._busy)
        self.refresh.setEnabled(idle)
        self.batch_start.setEnabled(idle)
        self.start_task.setEnabled(True)
        count=len(self._checked_tasks())
        label='切换到勾选任务' if active else ('加载后启动所选' if self._busy else '开始所选任务')
        self.start_task.setText(label+(f'（{count}）' if count else ''))
        if self._pending_start:
            self.stop_task.setEnabled(True); self.stop_task.setText('取消待启动任务')
        elif active:
            self.stop_task.setEnabled(not self._stop_requested)
            self.stop_task.setText('正在停止…' if self._stop_requested else '停止当前任务')
        elif self._busy:
            self.stop_task.setEnabled(not self._call_cancel.is_set())
            self.stop_task.setText('取消加载')
        else:
            self.stop_task.setEnabled(False); self.stop_task.setText('停止')

    def call(self, function, callback):
        if self._busy or self.task_worker is not None: return
        self._call_cancel = threading.Event()
        cancelled = self._call_cancel
        self._busy = True; self._sync_controls()
        thread = CallThread(function, self); self._calls.append(thread)
        outcome = {}
        thread.result.connect(lambda value: outcome.update(value=value))
        thread.error.connect(lambda message: outcome.update(error=message))
        def finished():
            try:
                if thread in self._calls: self._calls.remove(thread)
                self._busy = False
                if cancelled.is_set():
                    self.state.setText('加载已取消'); self.update_output_info('加载已结束，未应用取消后的结果。')
                elif 'error' in outcome:
                    self.state.setText('加载失败'); self.update_output_info(outcome['error']); self.warn_info.setText(outcome['error'])
                else:
                    callback(outcome.get('value'))
            except Exception as exc:
                self.state.setText('界面更新失败'); self.update_output_info('界面更新失败：'+type(exc).__name__)
            finally:
                self._sync_controls(); thread.deleteLater()
                self._start_pending()
        thread.finished.connect(finished); thread.start()

    def token_login(self):
        token = self.token_input.text().strip()
        if not token:
            self.warn_info.setText('请先填写 Token。'); return
        self.token = token; self.state.setText('正在连接')
        def received(result):
            if not isinstance(result, dict):
                self.warn_info.setText('连接失败：Token 过期、网络或代理异常，请检查后重试。')
                self.state.setText('连接失败'); return
            info = result.get('data', {}).get('user_info', {})
            self.user_info.setText('  ·  '.join(str(info.get(k, '')) for k in ('student_name','school_name','class_name')) or '已连接')
            self.warn_info.setText('连接成功。'); self.state.setText('已连接'); self.get_task_list()
        self.call(lambda: verify_token(token), received)

    def get_task_list(self):
        if self._busy: return
        choice = 1 if self.learn_task.isChecked() else 2
        if self.task_worker is not None:
            self.render_tasks(self._task_cache.get(choice,[]))
            self.update_output_info('运行期间可选择下一任务，点击“切换到所选”会先停止当前任务。')
            return
        if self.user_info.text() == '未获取': return
        self.state.setText('正在刷新任务')
        def fetch():
            self.public_info._task_choices = choice
            self.public_info.class_task = []
            PublicInfo.task_type = 'ClassTask'; PublicInfo.task_type_int = 2
            page = 1
            get_class_task(self.public_info, page)
            while self.public_info.task_total_count > page * 10:
                if self._call_cancel.is_set(): return None
                page += 1; get_class_task(self.public_info, page)
            return [task for group in self.public_info.class_task for task in group.get('records',[])
                    if task.get('over_status') != 3]
        def received(tasks):
            self._task_cache = {kind:[dict(t) for t in (tasks or []) if t.get('task_type')==kind]
                                for kind in (1,2)}
            known={self._task_key(task) for tasks in self._task_cache.values() for task in tasks if self._can_run(task)}
            self._checked_task_keys.intersection_update(known)
            self.render_tasks(self._task_cache[choice])
            self.public_info.task_list = list(self._visible_tasks)
        self.call(fetch, received)

    def render_tasks(self, tasks):
        previous=self._selected_task()
        previous_key=self._task_key(previous) if previous else None
        scroll=self.task_list.verticalScrollBar().value()
        self._smooth_tasks.stop()
        self._visible_tasks=[dict(task) for task in tasks]
        kind=1 if self.learn_task.isChecked() else 2
        self._task_cache[kind]=self._visible_tasks
        self.task_list.setUpdatesEnabled(False)
        blocker=QtCore.QSignalBlocker(self.task_list)
        try:
            self.task_list.setRowCount(len(tasks))
            for row,task in enumerate(self._visible_tasks):
                key=self._task_key(task); eligible=self._can_run(task)
                if not eligible: self._checked_task_keys.discard(key)
                check=QtWidgets.QTableWidgetItem()
                flags=Qt.ItemFlag.ItemIsSelectable | Qt.ItemFlag.ItemIsUserCheckable
                if eligible: flags|=Qt.ItemFlag.ItemIsEnabled
                check.setFlags(flags); check.setData(Qt.ItemDataRole.UserRole,task)
                check.setCheckState(Qt.CheckState.Checked if key in self._checked_task_keys else Qt.CheckState.Unchecked)
                if not eligible: check.setToolTip('该测试任务已完成，无法重复执行。')
                self.task_list.setItem(row,0,check)
                for col,value in enumerate([task['task_name'],str(task.get('progress',0))+'%',str(task.get('score') or 0)],1):
                    cell=QtWidgets.QTableWidgetItem(value); cell.setData(Qt.ItemDataRole.UserRole,task)
                    self.task_list.setItem(row,col,cell)
                if key==previous_key: self._select_task_row(row)
            self.task_list.verticalScrollBar().setValue(scroll)
        finally:
            del blocker; self.task_list.setUpdatesEnabled(True)
        self.empty.setText(f'共 {len(tasks)} 个任务 · 勾选多项后按列表顺序执行' if tasks else '当前没有可用任务。')
        self._update_selection_status()
        if self.task_worker is None and not self._pending_start: self.state.setText('可勾选多个任务')
        self.update_output_info('任务列表已更新。')

    def start(self):
        tasks=self._checked_tasks()
        if not tasks:
            task=self._selected_task()
            if task and self._can_run(task): tasks=[dict(task)]
        if not tasks:
            self.update_output_info('请勾选至少一个可执行任务。'); return
        if self.task_worker is not None or self._busy:
            index=max(0,getattr(self.task_worker,'current_index',1)-1) if self.task_worker else 0
            active=self._active_tasks[index] if index<len(self._active_tasks) else None
            if self.task_worker is not None and not self._stop_requested and active:
                tasks=[task for task in tasks if self._task_key(task)!=self._task_key(active)]
                if not tasks:
                    self.update_output_info('所选任务正在运行，无需重复启动。'); return
            self._pending_start=(tasks,len(tasks)>1)
            self.update_output_info(f'待启动 {len(tasks)} 项：'+ '、'.join(str(t.get('task_name','')) for t in tasks))
            if self.task_worker is not None: self._request_worker_stop()
            else:
                self._call_cancel.set(); self.state.setText('正在取消加载，随后启动勾选任务')
            self._sync_controls(); return
        self.run_tasks(tasks,len(tasks)>1)

    def start_batch(self):
        if self.task_worker is not None or self._busy: return
        tasks = [dict(t) for t in self._visible_tasks if t.get('progress',0) < 100]
        if tasks: self.run_tasks(tasks, True)
        else: self.update_output_info('没有未完成任务。')

    def run_tasks(self, tasks, batch):
        if self._busy or self.task_worker is not None or not tasks: return
        self._batch_mode = batch; self._outcome = ''; self._stop_requested = False
        self._active_tasks = [dict(task) for task in tasks]
        self.public_info.right_count = self.public_info.wrong_count = self.public_info.skip_count = 0
        self.progress_bar.setRange(0,100); self.progress_bar.setValue(0)
        self.progress_label.setText('0 / 0'); self.progress_right_label.setText('正确 0')
        self.progress_wrong_label.setText('错误 0'); self.progress_skip_label.setText('跳过 0')
        self.progress_task_label.setText(str(tasks[0].get('task_name','运行记录')))
        from util.assist_config import load as load_assist
        self.public_info._assist_config = load_assist(self.root_path)
        self.public_info._assist_failed = False
        self.public_info._assist_status = '本地未找到唯一答案'
        try:
            worker = self.task_worker_class(tasks, batch_mode=batch)
            self.task_worker = worker
            self.public_info._assist_callback = worker.request_manual
            worker.assist_requested.connect(self.show_manual_question)
            worker.task_progress.connect(self.update_progress)
            worker.task_finished.connect(self.update_output_info)
            if hasattr(worker,'task_completed'): worker.task_completed.connect(self.on_task_completed)
            worker.task_notice.connect(self.update_output_info)
            worker.task_error.connect(self.on_task_error)
            worker.batch_finished.connect(self.update_output_info)
            worker.finished.connect(lambda w=worker:self.worker_finished(w))
            self.state.setText('运行中'); self._sync_controls(); worker.start()
        except Exception as exc:
            self.task_worker = None; self._active_tasks = []
            self.state.setText('启动失败'); self.update_output_info('任务启动失败：'+type(exc).__name__)
            self._sync_controls()

    def on_task_completed(self, payload):
        completed = payload.get('task',{})
        key = self._task_key(completed)
        for tasks in self._task_cache.values():
            for task in tasks:
                if self._task_key(task)==key: task['progress']=100
        for row in range(self.task_list.rowCount()):
            item = self.task_list.item(row,1)
            task = item.data(Qt.ItemDataRole.UserRole) if item else None
            if task and self._task_key(task)==key:
                task=dict(task); task['progress']=100
                for col in (1,2,3): self.task_list.item(row,col).setData(Qt.ItemDataRole.UserRole,task)
                self.task_list.item(row,2).setText('100%')
        self._checked_task_keys.discard(key)
        self._refresh_checkboxes()
        self.update_output_info('任务已结束；队列中的下一项会继续执行，最新分数可点击刷新获取。')

    def on_task_error(self, message):
        self._outcome = '需安全验证' if '安全验证' in message else '已暂停'
        self.update_output_info(message)

    def worker_finished(self, finished_worker=None):
        worker = finished_worker or self.task_worker
        if worker is None or worker is not self.task_worker: return
        try:
            if getattr(self, '_manual_dialog', None):
                self._manual_dialog.reject(); self._manual_dialog = None
            stopped = self._stop_requested or not getattr(worker,'_is_running',True)
            self.state.setText(self._outcome or ('已停止，可选择下一任务' if stopped else '已完成，可选择下一任务'))
            self.update_output_info('任务已退出，已恢复任务选择和启动操作。')
        except Exception:
            self.update_output_info('任务已退出，界面已重置。')
        finally:
            self.task_worker = None; self._active_tasks = []; self._stop_requested = False
            self.public_info._assist_callback = None
            try: worker.deleteLater()
            except RuntimeError: pass
            self._sync_controls()
            self._start_pending()

    def _start_pending(self):
        if self.task_worker is not None or self._busy or not self._pending_start: return
        tasks, batch = self._pending_start; self._pending_start = None
        self.run_tasks(tasks,batch)

    def set_ui_enabled(self, enabled):
        # State comes from actual owned jobs, never a single blanket enable flag.
        self._sync_controls()

    def _request_worker_stop(self):
        if self.task_worker is None: return
        self._stop_requested = True
        self.task_worker.stop()
        if getattr(self,'_manual_dialog',None):
            self._manual_dialog.reject(); self._manual_dialog = None
        target = self._pending_start[0][0].get('task_name','') if self._pending_start else ''
        self.state.setText(f'正在停止，随后执行 {len(self._pending_start[0])} 项' if self._pending_start else '正在停止，等待当前请求结束')
        self.update_output_info('已请求停止；当前网络/模型请求结束后退出，不会强行销毁任务线程。')
        self._sync_controls()

    def stop_current_task(self):
        if self._pending_start:
            self._pending_start = None
            self.update_output_info('已取消待启动任务。')
        if self.task_worker is not None:
            if not self._stop_requested: self._request_worker_stop()
            else: self.state.setText('正在停止，未安排下一任务')
        elif self._busy:
            self._call_cancel.set(); self.state.setText('正在取消加载，等待当前请求结束')
        else:
            self.state.setText('当前没有运行任务，可直接选择下一项')
        self._sync_controls()

    def show_settings(self):
        dialog = QtWidgets.QDialog(self); dialog.setWindowTitle('运行设置'); dialog.resize(420,250)
        form = QtWidgets.QFormLayout(dialog)
        low = QtWidgets.QDoubleSpinBox(); high = QtWidgets.QDoubleSpinBox()
        for box,value in ((low,self.public_info.min_time),(high,self.public_info.max_time)):
            box.setRange(0.1,30); box.setSingleStep(0.1); box.setValue(value); box.setSuffix(' 秒')
        policy = QtWidgets.QComboBox(); policy.addItems(['暂停，等待人工处理','跳过，并记录到统计'])
        policy.setCurrentIndex(0 if self.public_info._unknown_policy == 'pause' else 1)
        form.addRow('答题间隔下限',low); form.addRow('答题间隔上限',high); form.addRow('不确定答案',policy)
        hint = QtWidgets.QLabel('较短间隔不代表服务端会更快处理。安全验证需在微信中完成。'); hint.setWordWrap(True); form.addRow(hint)
        buttons = QtWidgets.QDialogButtonBox(QtWidgets.QDialogButtonBox.StandardButton.Save | QtWidgets.QDialogButtonBox.StandardButton.Cancel)
        buttons.accepted.connect(dialog.accept); buttons.rejected.connect(dialog.reject); form.addRow(buttons)
        if dialog.exec():
            minimum = low.value(); maximum = max(minimum,high.value())
            self.public_info._min_time = minimum; self.public_info._max_time = maximum
            self.public_info._unknown_policy = 'pause' if policy.currentIndex()==0 else 'skip'
            path = os.path.join(self.root_path,'config','config.json')
            with open(path,encoding='utf-8') as f: config = json.load(f)
            config.update(min_time=minimum,max_time=maximum,unknown_policy=self.public_info._unknown_policy)
            temporary = path+'.tmp'
            with open(temporary,'w',encoding='utf-8') as f: json.dump(config,f,ensure_ascii=False,indent=2)
            os.replace(temporary,path); self.update_output_info('运行设置已保存。')

    def show_about(self):
        QMessageBox.information(self,'关于词序','词序 1.5\n本地匹配增强版，默认关闭模型 API\n基于 Easy_Cidaren 的本地修改版\n上游作者：ularch 及项目贡献者\nGPL-3.0；完整来源与修改说明见 NOTICES.md 和 LICENSE。')

    def closeEvent(self, event):
        if self._busy or self.task_worker is not None:
            self.stop_current_task()
            self.update_output_info('请等待当前网络请求或任务结束后关闭。'); event.ignore()
        else:
            event.accept()

    def _select_task_row(self, row):
        """
        勾选单选框时同步选中表格行
        :param row:
        :return:
        """
        item = self.task_list.item(row, 1)
        if item:
            self.task_list.setCurrentItem(item)

    def _on_task_item_clicked(self,item):
        # Native checkbox toggling already handles column 0; a row click toggles its checkbox once.
        if item.column()==0: return
        check=self.task_list.item(item.row(),0)
        task=item.data(Qt.ItemDataRole.UserRole)
        if check and task and self._can_run(task):
            check.setCheckState(Qt.CheckState.Unchecked if check.checkState()==Qt.CheckState.Checked else Qt.CheckState.Checked)

    def update_progress(self, progress_text):
        """
        更新进度
        :param progress_text: 格式 "done/total|right|wrong|skip|index/total|task_name"
        :return:
        """
        # 先按 | 切分(避免 index/total 段中的 / 破坏 done/total 解析)
        segments = progress_text.split('|')
        dt = segments[0].split('/')
        if len(dt) == 2:
            try:
                done = int(dt[0])
                total = int(dt[1])
                self.progress_bar.setMaximum(total)
                self.progress_bar.setValue(done)
                self.progress_label.setText(f"{done}/{total}")
                if len(segments) > 2:
                    self.progress_right_label.setText(f"正确 {segments[1]}")
                    self.progress_wrong_label.setText(f"错误 {segments[2]}")
                    if len(segments) > 3:
                        self.progress_skip_label.setText(f"跳过 {segments[3]}")
                        if len(segments) > 5:
                            self.progress_task_label.setText(f"[{segments[4]}] {segments[5]}")
            except ValueError:
                pass


    def get_token(self):
        from view.token_capture import CaptureDialog
        dialog = CaptureDialog(self.root_path,self)
        dialog.captured.connect(self.use_captured_token)
        dialog.exec()

    def use_captured_token(self,token):
        self.token_input.setText(token)
        self.warn_info.setText('Token 已获取，正在连接账号…')
        self.token_login()

    def import_token(self):
        from api.capture_client import token_from_text
        token = token_from_text(QtWidgets.QApplication.clipboard().text())
        if token:
            self.use_captured_token(token)
        else:
            self.warn_info.setText('剪贴板中没有识别到 UserToken。支持原始 Token、请求头、JSON 或 cURL。')

    def show_model_settings(self):
        from view.model_assist import ModelSettings
        dialog = ModelSettings(self.root_path,self)
        if dialog.exec(): self.update_output_info('模型辅助设置已保存，下次开始任务时生效。')

    def show_manual_question(self,payload):
        from view.model_assist import ManualQuestion
        if getattr(self,'_manual_dialog',None): self._manual_dialog.reject()
        worker=self.task_worker
        if not worker or not worker.isRunning(): return
        dialog=self._manual_dialog=ManualQuestion(payload["prompt"],self)
        dialog.resolved.connect(lambda result:worker.resolve_manual(result,payload["generation"]))
        dialog.show()
