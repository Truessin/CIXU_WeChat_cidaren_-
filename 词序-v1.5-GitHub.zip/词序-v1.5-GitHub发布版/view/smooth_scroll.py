"""Smooth angle-wheel scrolling; preserve native pixel/trackpad gestures and dragging."""
from PyQt6 import QtCore,QtWidgets
from PyQt6.QtCore import Qt


class SmoothScroller(QtCore.QObject):
    user_scrolled=QtCore.pyqtSignal(int)
    settled=QtCore.pyqtSignal()

    def __init__(self,area,step=28):
        super().__init__(area)
        self.area=area; self.animations={}; self.targets={}
        self.viewport=area.viewport(); self.viewport.installEventFilter(self)
        for axis,bar in [('vertical',area.verticalScrollBar()),('horizontal',area.horizontalScrollBar())]:
            if axis=='vertical': bar.setSingleStep(step)
            animation=QtCore.QPropertyAnimation(bar,b'value',self)
            animation.setDuration(150); animation.setEasingCurve(QtCore.QEasingCurve.Type.OutCubic)
            animation.finished.connect(self.settled.emit)
            self.animations[axis]=animation
            bar.sliderPressed.connect(lambda a=axis:self.stop(a))
            bar.actionTriggered.connect(lambda action,a=axis:self.stop(a))
            bar.rangeChanged.connect(lambda low,high,a=axis:self.clamp(a,low,high))

    def stop(self,axis=None):
        for name,animation in self.animations.items():
            if axis is None or name==axis:
                animation.stop(); self.targets.pop(name,None)

    def clamp(self,axis,low,high):
        if axis in self.targets:
            target=max(low,min(high,self.targets[axis]))
            if target!=self.targets[axis]:
                self.targets[axis]=target
                self.animations[axis].setEndValue(target)

    def scroll_to(self,value,axis='vertical',duration=150):
        bar=self.area.verticalScrollBar() if axis=='vertical' else self.area.horizontalScrollBar()
        target=max(bar.minimum(),min(bar.maximum(),round(value)))
        animation=self.animations[axis]; animation.stop()
        self.targets[axis]=target
        if target==bar.value(): return
        animation.setDuration(duration); animation.setStartValue(bar.value()); animation.setEndValue(target)
        animation.start()

    def eventFilter(self,watched,event):
        if watched is not self.viewport: return False
        if event.type()==QtCore.QEvent.Type.KeyPress:
            if event.key() in (Qt.Key.Key_Up,Qt.Key.Key_PageUp,Qt.Key.Key_Home):
                self.stop(); self.user_scrolled.emit(1)
            return False
        if event.type()!=QtCore.QEvent.Type.Wheel: return False
        if event.modifiers() & Qt.KeyboardModifier.ControlModifier: return False
        delta=event.pixelDelta()
        angle=event.angleDelta()
        horizontal=abs(angle.x())>abs(angle.y()) or bool(event.modifiers() & Qt.KeyboardModifier.ShiftModifier)
        axis='horizontal' if horizontal else 'vertical'
        raw=(delta.x() if horizontal and delta.x() else delta.y()) if not delta.isNull() else (angle.x() if horizontal and angle.x() else angle.y())
        if not raw: return False
        self.user_scrolled.emit(1 if raw>0 else -1)
        if not delta.isNull():
            # Pixel deltas already carry native trackpad acceleration and momentum.
            self.stop(axis); return False
        bar=self.area.horizontalScrollBar() if horizontal else self.area.verticalScrollBar()
        if bar.maximum()<=bar.minimum(): return False
        animation=self.animations[axis]
        base=self.targets.get(axis,bar.value()) if animation.state()==QtCore.QAbstractAnimation.State.Running else bar.value()
        distance=raw/120*bar.singleStep()*max(1,QtWidgets.QApplication.wheelScrollLines())
        target=max(bar.minimum(),min(bar.maximum(),base-distance))
        if round(target)==bar.value() and animation.state()!=QtCore.QAbstractAnimation.State.Running:
            return False
        self.scroll_to(target,axis)
        event.accept(); return True
