"""User-triggered capture dialog with explicit scope and cancellation."""
from PyQt6 import QtCore,QtWidgets
from api.capture_client import CaptureClient,token_from_text
from api.capture_system import pending_recovery,recover

STUDENT_URL='https://app.vocabgo.com/student/'


class CaptureWorker(QtCore.QThread):
    event=QtCore.pyqtSignal(object)
    def __init__(self,root):
        super().__init__(); self.client=CaptureClient(root,self.event.emit)
    def run(self):
        try: self.client.run()
        except Exception as exc: self.event.emit({'event':'error','message':str(exc)})
    def stop(self): self.client.stop()


class CaptureDialog(QtWidgets.QDialog):
    captured=QtCore.pyqtSignal(str)
    def __init__(self,root,parent=None):
        super().__init__(parent); self.root=root; self.worker=None; self.token=None
        self.setWindowTitle('获取 Token'); self.resize(600,400)
        layout=QtWidgets.QVBoxLayout(self); layout.setSpacing(14)
        title=QtWidgets.QLabel('在微信打开词达人，自动完成连接')
        title.setStyleSheet('font-size:19px;font-weight:600;'); layout.addWidget(title)
        instructions=QtWidgets.QLabel('1. 点击“开始获取”\n2. 将学生端链接粘贴到电脑微信，点击打开\n3. 在词达人中切换一个页面，获取成功后自动填入并连接')
        instructions.setWordWrap(True); layout.addWidget(instructions)
        scope=QtWidgets.QLabel('开始后会临时设置本机系统代理，并在当前用户证书库添加本次生成的证书。仅提取 app.vocabgo.com 请求中的 UserToken；其他站点不解密。成功、取消或 3 分钟超时后自动恢复原代理并移除本次证书。')
        scope.setWordWrap(True); scope.setStyleSheet('color:#68768b;background:#f3f5f8;padding:12px;border-radius:8px;'); layout.addWidget(scope)
        self.status=QtWidgets.QLabel('准备就绪。不会把 Token 写入文件。'); self.status.setWordWrap(True); layout.addWidget(self.status,1)
        row=QtWidgets.QHBoxLayout()
        self.copy=QtWidgets.QPushButton('复制学生端链接'); self.copy.clicked.connect(self.copy_link); row.addWidget(self.copy)
        self.start=QtWidgets.QPushButton('开始获取'); self.start.setObjectName('primary'); self.start.clicked.connect(self.begin); row.addWidget(self.start)
        self.cancel=QtWidgets.QPushButton('关闭'); self.cancel.clicked.connect(self.cancel_capture); row.addWidget(self.cancel); layout.addLayout(row)
        self.repair=QtWidgets.QPushButton('恢复捕获设置'); self.repair.clicked.connect(self.recover_settings); layout.addWidget(self.repair)
        if pending_recovery(root):
            self.status.setText('发现上次未完成的恢复记录，请先点击“恢复捕获设置”。'); self.start.setEnabled(False)

    def copy_link(self):
        QtWidgets.QApplication.clipboard().setText(STUDENT_URL)
        self.status.setText('链接已复制。请粘贴到电脑微信并点击打开。')

    def begin(self):
        if self.worker and self.worker.isRunning(): return
        self.token=None; self.worker=CaptureWorker(self.root)
        self.worker.event.connect(self.on_event); self.worker.finished.connect(self.finished_capture)
        self.start.setEnabled(False); self.repair.setEnabled(False); self.cancel.setText('取消获取')
        self.status.setText('正在启动内置获取服务…'); self.worker.start()

    def on_event(self,event):
        kind=event.get('event')
        if kind=='ready':
            QtWidgets.QApplication.clipboard().setText(STUDENT_URL)
            self.status.setText('获取服务已就绪，链接已复制。请粘贴到电脑微信，点击打开词达人并切换一个页面。')
        elif kind in ('status','error'): self.status.setText(event.get('message',''))
        elif kind=='token': self.token=event.get('token')

    def finished_capture(self):
        self.worker.deleteLater(); self.worker=None
        self.start.setEnabled(not pending_recovery(self.root)); self.repair.setEnabled(True); self.cancel.setEnabled(True); self.cancel.setText('关闭')
        if self.token:
            self.captured.emit(self.token); self.accept()
        elif pending_recovery(self.root): self.status.setText('临时设置尚未完全恢复，请点击“恢复捕获设置”。')
        elif self.status.text().startswith('正在取消'): self.status.setText('已取消，临时设置已恢复。')

    def cancel_capture(self):
        if self.worker and self.worker.isRunning():
            self.worker.stop(); self.cancel.setEnabled(False); self.status.setText('正在取消并恢复设置，请稍候…')
        else: self.reject()

    def recover_settings(self):
        try:
            self.status.setText(recover(self.root)); self.start.setEnabled(True)
        except Exception:
            self.status.setText('恢复失败。请检查 Windows 当前用户证书权限，勿删除 .capture 中的恢复记录。')

    def reject(self):
        if self.worker and self.worker.isRunning(): self.cancel_capture()
        else: super().reject()

    def closeEvent(self,event):
        if self.worker and self.worker.isRunning(): self.cancel_capture(); event.ignore()
        else: event.accept()
