# -*- mode: python ; coding: utf-8 -*-


from pathlib import Path
from PyInstaller.utils.hooks import collect_data_files, copy_metadata, collect_all
root = Path(SPECPATH)
rs_datas, rs_binaries, rs_hidden = collect_all('mitmproxy_rs')

a = Analysis(
    [str(root / 'main.py')],
    pathex=[str(root)],
    binaries=rs_binaries,
    datas=[(str(root / 'en_core_web_sm'), 'en_core_web_sm')] + rs_datas + collect_data_files('mitmproxy') + collect_data_files('publicsuffix2') + copy_metadata('mitmproxy') + copy_metadata('mitmproxy-rs'),
    hiddenimports=['spacy.lang.en', 'mitmproxy_windows'] + rs_hidden,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=['matplotlib', 'tkinter', 'torch'],
    noarchive=False,
    optimize=0,
)
# Qt uses Windows system ICU. A different ICU on PATH must not shadow it.
a.binaries = [item for item in a.binaries if Path(item[0]).name.casefold() not in {'icuuc.dll', 'icudt78.dll'}]
pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name='CiXu',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    console=False,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
)
coll = COLLECT(
    exe,
    a.binaries,
    a.datas,
    strip=False,
    upx=True,
    upx_exclude=[],
    name='CiXu',
)
