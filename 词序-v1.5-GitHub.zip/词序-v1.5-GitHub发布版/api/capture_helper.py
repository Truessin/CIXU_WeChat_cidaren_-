"""Token capture subprocess: only app.vocabgo.com request headers are considered."""
import asyncio
import json
import os
from pathlib import Path
import secrets
import shutil
import sys
import tempfile

TARGET_HOST = 'app.vocabgo.com'


def extract_token(host, headers):
    if str(host).lower().rstrip('.') != TARGET_HOST:
        return None
    token = headers.get('usertoken')
    if not isinstance(token, str): return None
    token = token.strip()
    if not token or len(token) > 4096 or any(c.isspace() or ord(c) < 32 for c in token):
        return None
    return token


async def capture():
    from api.capture_system import SystemCapture, pending_recovery, capture_lock
    root = Path(os.environ['CIXU_CAPTURE_ROOT']).resolve()
    test = os.environ.get('CIXU_CAPTURE_TEST') == '1'
    reader, writer = await asyncio.open_connection('127.0.0.1', int(os.environ['CIXU_CAPTURE_IPC_PORT']))
    def send(event, **values):
        writer.write((json.dumps({'event':event, **values}, ensure_ascii=False)+'\n').encode('utf-8'))
    send('hello', secret=os.environ['CIXU_CAPTURE_SECRET'])
    await writer.drain()
    session = None; system = None; master = None; token = None; lock = None
    cleanup_ok = False; watcher = None; deadline = None
    try:
        from mitmproxy import options, http
        from mitmproxy.tools.dump import DumpMaster
        lock = capture_lock(root)
        lock.__enter__()
        if not test and pending_recovery(root):
            raise RuntimeError('存在上次未恢复的设置，请先点击“恢复捕获设置”。')
        folder = root / '.capture'; folder.mkdir(exist_ok=True)
        session = Path(tempfile.mkdtemp(prefix='session-', dir=folder))
        send('status', message='正在准备内置获取服务…')
        opts = options.Options(listen_host='127.0.0.1', listen_port=0, confdir=str(session),
                               allow_hosts=[r'^app\.vocabgo\.com(?::\d+)?$'])
        master = DumpMaster(opts, with_termlog=False, with_dumper=False)
        master.options.update(connection_strategy='lazy', **({'upstream_cert':False} if test else {}))
        class CaptureAddon:
            async def running(self):
                nonlocal system
                try:
                    servers = master.addons.get('proxyserver').servers
                    addresses = [address for server in servers for address in server.listen_addrs]
                    port = addresses[0][1]
                    certificate = session / 'mitmproxy-ca-cert.pem'
                    if not test:
                        system = SystemCapture(root, session, port)
                        # Bounded certificate tool runs off the proxy event loop.
                        await asyncio.to_thread(system.enable, certificate)
                    send('ready', port=port, certificate=str(certificate) if test else '')
                    await writer.drain()
                except Exception:
                    send('error', message='获取服务准备失败。请检查证书权限和本地端口，结束后可点击恢复捕获设置。')
                    master.shutdown()

            def request(self, flow):
                nonlocal token
                candidate = extract_token(flow.request.host, flow.request.headers)
                if candidate:
                    token = candidate
                    if test: flow.response = http.Response.make(204)
                    # Allow the current request to finish before shutting down the proxy.
                    asyncio.get_running_loop().call_later(0.25, master.shutdown)

        master.addons.add(CaptureAddon())
        async def watch_parent():
            try:
                while await reader.readline():
                    master.shutdown()
                    return
            finally:
                master.shutdown()
        async def timeout():
            await asyncio.sleep(180)
            send('status', message='等待已超时。请确认微信使用系统代理，并重新打开学生端后再试。')
            master.shutdown()
        watcher = asyncio.create_task(watch_parent()); deadline = asyncio.create_task(timeout())
        await master.run()
    except Exception as exc:
        # Never report headers, flows or raw exception strings containing credentials.
        send('error', message=f'内置获取服务未能完成（{type(exc).__name__}）。可取消后重试，或使用手动导入。')
    finally:
        if master: master.shutdown()
        for task in (watcher, deadline):
            if task: task.cancel()
        if watcher or deadline:
            await asyncio.gather(*(t for t in (watcher,deadline) if t), return_exceptions=True)
        try:
            message = await asyncio.to_thread(system.restore) if system else '临时服务已关闭。'
            cleanup_ok = True
            send('status', message=message)
        except Exception:
            send('error', message='临时设置未完全恢复，请点击“恢复捕获设置”。恢复记录已保留。')
        if session and cleanup_ok and session.resolve().parent == root / '.capture':
            shutil.rmtree(session.resolve(), ignore_errors=True)
        if lock:
            try: lock.__exit__(None, None, None)
            except RuntimeError: pass
        if token and cleanup_ok: send('token', token=token)
        send('done', cleaned=cleanup_ok)
        try: await writer.drain()
        except (ConnectionError, BrokenPipeError): pass
        writer.close()
        try: await writer.wait_closed()
        except ConnectionError: pass


def run():
    # A windowed executable has no stdio objects. mitmproxy and dependencies may inspect them.
    for stream in ('stdout', 'stderr'):
        if getattr(sys,stream) is None: setattr(sys,stream,open(os.devnull,'w'))
    if sys.stdin is None: sys.stdin = open(os.devnull)
    asyncio.run(capture())
    return 0
