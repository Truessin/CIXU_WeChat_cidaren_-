"""Loopback IPC client for an opt-in token capture helper. No tokens are written to disk."""
import json
import os
from pathlib import Path
import re
import secrets
import socket
import subprocess
import sys
import threading
import time


def token_from_text(text):
    text = str(text).strip()
    def valid(value):
        return isinstance(value,str) and 8 <= len(value.strip()) <= 4096 and not any(c.isspace() for c in value.strip())
    try:
        parsed = json.loads(text)
        def find(value):
            if isinstance(value,dict):
                for key,item in value.items():
                    if str(key).lower()=='usertoken' and valid(item): return item.strip()
                for item in value.values():
                    result=find(item)
                    if result: return result
            return None
        found=find(parsed)
        if found: return found
    except (ValueError,RecursionError): pass
    match=re.search(r"(?im)(?:^|[\s\"'])usertoken\s*:\s*([^\s\"'\\]+)",text)
    if match and valid(match[1]): return match[1]
    if valid(text) and not any(c in text for c in '{}[]<>:'):
        return text
    return None


class CaptureClient:
    def __init__(self, root, emit, test=False):
        self.root=Path(root).resolve(); self.emit=emit; self.test=test
        self.cancel=threading.Event()
        self.process=None

    def stop(self):
        self.cancel.set()

    def run(self):
        if self.cancel.is_set(): return
        secret=secrets.token_hex(32)
        with socket.socket() as listener:
            listener.bind(('127.0.0.1',0)); listener.listen(4); listener.settimeout(0.5)
            env=os.environ.copy(); env.update(CIXU_CAPTURE_ROOT=str(self.root), CIXU_CAPTURE_SECRET=secret,
                CIXU_CAPTURE_IPC_PORT=str(listener.getsockname()[1]), CIXU_CAPTURE_TEST='1' if self.test else '0')
            if getattr(sys,'frozen',False): command=[sys.executable,'--capture-helper']
            else: command=[sys.executable,str(Path(__file__).resolve().parent.parent/'main.py'),'--capture-helper']
            self.process=subprocess.Popen(command,cwd=self.root,env=env,stdin=subprocess.DEVNULL,
                stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,creationflags=subprocess.CREATE_NO_WINDOW)
            connection=None; cleaned=False
            try:
                deadline=time.monotonic()+35
                while time.monotonic()<deadline:
                    if self.process.poll() is not None: raise RuntimeError('内置获取进程启动失败，请检查运行目录。')
                    try:
                        candidate,_=listener.accept(); candidate.settimeout(5)
                    except socket.timeout: continue
                    try:
                        raw=b''
                        while not raw.endswith(b'\n') and len(raw)<=16384:
                            part=candidate.recv(1)
                            if not part: break
                            raw+=part
                        hello=json.loads(raw)
                        if len(raw)>16384 or not secrets.compare_digest(str(hello.get('secret','')),secret):
                            candidate.close(); continue
                        connection=candidate; break
                    except (ValueError,OSError):
                        candidate.close()
                if connection is None: raise RuntimeError('内置获取服务连接超时。')
                connection.settimeout(0.5)
                buffer=b''; stopped=False; stop_deadline=None
                # Use recv instead of a timed file object (file objects become unusable on timeout).
                while True:
                    if self.cancel.is_set() and not stopped:
                        connection.sendall(b'{"command":"stop"}\n'); stopped=True
                        stop_deadline=time.monotonic()+50
                    if stop_deadline and time.monotonic()>stop_deadline:
                        raise RuntimeError('等待恢复设置超时，请点击“恢复捕获设置”。')
                    try: chunk=connection.recv(8192)
                    except socket.timeout:
                        if self.process.poll() is not None: break
                        continue
                    if not chunk: break
                    buffer+=chunk
                    if len(buffer)>32768: raise RuntimeError('获取服务返回了无法识别的数据。')
                    while b'\n' in buffer:
                        raw,buffer=buffer.split(b'\n',1); event=json.loads(raw)
                        if event.get('event')=='done': cleaned=event.get('cleaned',False)
                        if event.get('event') != 'token' or not self.cancel.is_set():
                            self.emit(event)
                if not cleaned: raise RuntimeError('获取进程已结束，请检查并恢复捕获设置后重试。')
            finally:
                # EOF tells the helper to restore its settings, including if this GUI closes.
                if connection: connection.close()
                try: self.process.wait(timeout=45)
                except subprocess.TimeoutExpired:
                    self.process.terminate()
                    self.process.wait(timeout=5)
                    self.emit({'event':'error','message':'获取进程异常，已保留恢复记录，请点击恢复捕获设置。'})
