"""Temporary Windows proxy/certificate changes for an explicitly started capture.
CiXu local modification, 2026-10-19. Recovery data never contains a user token.
"""
import ctypes
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import winreg
import ssl
from contextlib import contextmanager
import msvcrt

KEY = r'Software\Microsoft\Windows\CurrentVersion\Internet Settings'
FIELDS = ('ProxyEnable', 'ProxyServer', 'ProxyOverride', 'AutoConfigURL')


def read_settings():
    with winreg.OpenKey(winreg.HKEY_CURRENT_USER, KEY, 0, winreg.KEY_READ) as key:
        result = {}
        for name in FIELDS:
            try:
                value, kind = winreg.QueryValueEx(key, name)
                result[name] = [value, kind]
            except FileNotFoundError:
                result[name] = None
        return result


def write_setting(name, value):
    with winreg.OpenKey(winreg.HKEY_CURRENT_USER, KEY, 0, winreg.KEY_SET_VALUE) as key:
        if value is None:
            try: winreg.DeleteValue(key, name)
            except FileNotFoundError: pass
        else:
            winreg.SetValueEx(key, name, 0, value[1], value[0])


def refresh():
    for option in (39, 37):
        if not ctypes.windll.wininet.InternetSetOptionW(None, option, None, 0):
            raise OSError('无法通知 Windows 更新代理设置。')


def certutil(*args):
    executable = Path(os.environ.get('SystemRoot', r'C:\Windows')) / 'System32' / 'certutil.exe'
    result = subprocess.run([str(executable), '-user', *args], capture_output=True,
                            creationflags=subprocess.CREATE_NO_WINDOW, timeout=20)
    if result.returncode:
        raise RuntimeError('当前用户证书操作失败，请检查 Windows 证书权限。')


def certificate_present(thumb):
    return any(encoding == 'x509_asn' and hashlib.sha1(cert).hexdigest() == thumb
               for cert, encoding, trust in ssl.enum_certificates('ROOT'))


@contextmanager
def capture_lock(root):
    folder = Path(root) / '.capture'
    folder.mkdir(exist_ok=True)
    if folder.resolve() != Path(root).resolve() / '.capture':
        raise ValueError('捕获目录不能是指向应用目录外的链接。')
    with open(folder / 'active.lock', 'a+b') as handle:
        handle.seek(0, 2)
        if handle.tell() == 0:
            handle.write(b'0'); handle.flush()
        handle.seek(0)
        try:
            msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
        except OSError:
            raise RuntimeError('另一个词序窗口正在获取 Token，请先取消该窗口的获取。') from None
        try:
            yield
        finally:
            handle.seek(0); msvcrt.locking(handle.fileno(), msvcrt.LK_UNLCK, 1)


class SystemCapture:
    def __init__(self, root, session, port):
        self.root = Path(root).resolve()
        self.session = Path(session).resolve()
        if self.session.parent != self.root / '.capture':
            raise ValueError('捕获目录必须在应用目录内。')
        self.journal = self.session / 'recovery.json'
        self.data = {'original': read_settings(), 'expected': {
            'ProxyServer': [f'127.0.0.1:{int(port)}', winreg.REG_SZ],
            'ProxyOverride': ['<local>', winreg.REG_SZ],
            'AutoConfigURL': None,
            'ProxyEnable': [1, winreg.REG_DWORD],
        }, 'changed': [], 'certificate': None}

    def save(self):
        temporary = self.journal.with_suffix('.tmp')
        temporary.write_text(json.dumps(self.data, ensure_ascii=False), encoding='utf-8')
        os.replace(temporary, self.journal)

    def enable(self, certificate):
        # This certificate was freshly generated in a new random session directory.
        # Record its exact hash before installation, so an interrupted install is recoverable.
        from cryptography import x509
        from cryptography.hazmat.primitives import hashes
        cert = x509.load_pem_x509_certificate(Path(certificate).read_bytes())
        self.data['certificate'] = cert.fingerprint(hashes.SHA1()).hex()
        self.save()
        certutil('-addstore', 'Root', str(certificate))
        for name in ('ProxyServer', 'ProxyOverride', 'AutoConfigURL', 'ProxyEnable'):
            self.data['changed'].append(name)
            self.save()
            write_setting(name, self.data['expected'][name])
        refresh()

    def restore(self):
        messages = []
        current = read_settings()
        # Preserve concurrent proxy changes made by the user or another program.
        owns_proxy = current.get('ProxyServer') == self.data['expected']['ProxyServer']
        if owns_proxy:
            # Disable or restore the original enable flag first; restore server last.
            for name in ('ProxyEnable', 'AutoConfigURL', 'ProxyOverride', 'ProxyServer'):
                if name in self.data['changed'] and current.get(name) == self.data['expected'][name]:
                    write_setting(name, self.data['original'].get(name))
            refresh()
            messages.append('原代理设置已恢复。')
        elif self.data['changed']:
            messages.append('代理设置已被其他程序改变，保留当前设置。')
        thumb = self.data.get('certificate')
        if thumb:
            if not re.fullmatch(r'[0-9a-f]{40}', thumb):
                raise ValueError('恢复记录中的证书标识无效。')
            if certificate_present(thumb):
                certutil('-delstore', 'Root', thumb)
            if certificate_present(thumb):
                raise RuntimeError('临时证书仍然存在，请重试恢复。')
            self.data['certificate'] = None
        self.data['changed'] = []
        self.save()
        self.journal.unlink(missing_ok=True)
        return ' '.join(messages) or '临时设置已清理。'


def pending_recovery(root):
    return sorted((Path(root) / '.capture').glob('*/recovery.json'))


def recover(root):
    with capture_lock(root):
        return _recover_unlocked(root)


def _recover_unlocked(root):
    results = []
    for journal in pending_recovery(root):
        data = json.loads(journal.read_text(encoding='utf-8'))
        server = data.get('expected', {}).get('ProxyServer', [''])[0]
        if not re.fullmatch(r'127\.0\.0\.1:\d+', server):
            raise ValueError('无法识别的恢复记录。')
        manager = SystemCapture.__new__(SystemCapture)
        manager.root = Path(root).resolve(); manager.session = journal.parent.resolve()
        if manager.session.parent != manager.root / '.capture':
            raise ValueError('恢复目录不在应用捕获目录内。')
        manager.journal = journal; manager.data = data
        results.append(manager.restore())
        shutil.rmtree(manager.session)
    return '\n'.join(results) or '没有待恢复的捕获设置。'
