import os
import sys

import requests
from requests import exceptions
from publicInfo.publicInfo import PublicInfo

from decryptencrypt.encrypt_md5 import encrypt_md5

path = os.path.dirname(__file__)
root_path = os.path.dirname(sys.executable) if getattr(sys, 'frozen', False) else os.path.dirname(path)

class TimedSession(requests.Session):
    def request(self, method, url, **kwargs):
        kwargs.setdefault('timeout', (5, 20))
        return super().request(method, url, **kwargs)


Token = '' 
user_age = 'Mozilla/5.0 (Linux; Android 8.1.2; LIO-AN00 Build/LIO-AN00; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/92.0.4515.131 Safari/537.36 MMWEBID/4462 MicroMessenger/8.0.20.2100(0x28001438) Process/toolsmp WeChat/arm64 Weixin Android Tablet NetType/WIFI Language/zh_CN ABI/arm64'
headers = {"Host": "app.vocabgo.com",
           "Accept": "application/json, text/plain, */*",
           "Abc": encrypt_md5(user_age),
           "Authorization-V": "cfcd208495d565ef66e7dff9f98764da",
           "X-Requested-With": "XMLHttpRequest",
           "User-Agent": user_age,
           "Accept-Language": "*",
           "Sec-Fetch-Site": "same-origin",
           "Sec-Fetch-Mode": "cors",
           "Sec-Fetch-Dest": "empty",
           "Referer": "https://app.vocabgo.com/student/",
           "Accept-Encoding": PublicInfo(root_path).accept_encoding
           }

rqs_session = rqs2_session = rqs3_session = class_task_request = rsq_self_built = ''


def set_token(token):
    # 更新全局变量
    global Token
    from util.privacy import register_secret
    register_secret(token)
    Token = token
    global rqs_session, rqs2_session, rqs3_session, class_task_request, rsq_self_built

    rqs_session = TimedSession()
    rqs_session.headers = headers.copy()
    rqs_session.headers.update({'Usertoken': Token})
    # submit request header
    rqs2_session = TimedSession()
    rqs2_session.headers = headers.copy()
    rqs2_session.headers.update(
        {"Authorization-V": "c4ca4238a0b923820dcc509a6f75849b", 'Usertoken': Token, "Origin": "https://app.vocabgo.com",
         "Content-Type": "application/json", })
    rqs3_session = TimedSession()
    rqs3_session.headers = headers.copy()
    rqs3_session.headers.update({"Origin": "https://app.vocabgo.com", 'Usertoken': Token,
                                 "Content-Type": "application/json"})
    class_task_request = TimedSession()
    class_task_request.headers = headers.copy()
    class_task_request.headers.update({"Usertoken": Token})
    # self_built request
    rsq_self_built = TimedSession()
    rsq_self_built.headers = headers.copy()
    rsq_self_built.headers.update(
        {"Origin": "https://app.vocabgo.com", "Referer": "https://app.vocabgo.com", "Host": 'resource.vocabgo.com',
         "X-Requested-With": 'com.tencent.mm'})
    rsq_self_built.headers.pop('Authorization-V')
    rsq_self_built.headers.pop('Abc')

if __name__ == '__main__':
    path = os.path.dirname(__file__)
    root_path = os.path.dirname(path)
    print(root_path)
    print(PublicInfo(root_path).accept_encoding)
