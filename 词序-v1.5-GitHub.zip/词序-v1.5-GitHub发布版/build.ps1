﻿$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot
python -m venv .venv
if ($LASTEXITCODE -ne 0) { throw '无法创建 Python 环境，请安装 Python 3.13 x64。' }
$runtime = Join-Path $PSScriptRoot '.venv\Scripts\python.exe'
& $runtime -m pip install -r requirements.txt 'pytest==9.1.1' 'pyinstaller==6.22.3'
if ($LASTEXITCODE -ne 0) { throw '依赖安装失败。' }
$testRoot = Join-Path $PSScriptRoot ('work\tests-' + [guid]::NewGuid().ToString('N'))
& $runtime -m pytest tests -q --basetemp=$testRoot
if ($LASTEXITCODE -ne 0) { throw '测试失败，未进行打包。' }
& $runtime -m PyInstaller --noconfirm CiXu.spec
if ($LASTEXITCODE -ne 0) { throw '打包失败。' }
$publicConfig = Join-Path $PSScriptRoot 'dist\CiXu\config'
New-Item -ItemType Directory -Path $publicConfig -Force | Out-Null
# Only ship reviewed defaults. Never copy local config, learning caches or credentials.
foreach ($name in @('config', 'model_assist')) {
    Copy-Item -LiteralPath (Join-Path $PSScriptRoot "config\$name.example.json") -Destination (Join-Path $publicConfig "$name.json") -Force
    Copy-Item -LiteralPath (Join-Path $PSScriptRoot "config\$name.example.json") -Destination $publicConfig -Force
}
foreach ($name in @('answer_lib', 'word_pool', 'verified_answers')) {
    Set-Content -LiteralPath (Join-Path $publicConfig "$name.json") -Value '{}' -Encoding ascii
}
Copy-Item -LiteralPath LICENSE,NOTICES.md,README.md -Destination dist\CiXu -Force
Write-Host '完成：dist\CiXu\CiXu.exe'
