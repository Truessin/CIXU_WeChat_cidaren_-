"""Deterministic language normalization; no model service or network requests."""
import html
import re
import unicodedata
from urllib.parse import unquote


def plain(value):
    if value is None:
        return ''
    if isinstance(value, (list, tuple)):
        value = ' '.join(str(item) for item in value if item is not None)
    value = html.unescape(unquote(str(value)))
    return unicodedata.normalize('NFKC', re.sub(r'<[^>]*>', ' ', value)).strip()


def sentence_key(value):
    return ''.join(c for c in plain(value).casefold() if c.isalnum())


_POS = re.compile(
    r'^(adjective|adverb|pronoun|preposition|conjunction|interjection|noun|verb|'
    r'adj|adv|pron|prep|conj|vt|vi|n|v)\.?'
    r'(?=\s|[\u4e00-\u9fff(；;:]|$)\s*', re.I)
_ALIASES = {'n':'noun', 'v':'verb', 'vt':'verb', 'vi':'verb',
            'adj':'adjective', 'adv':'adverb', 'pron':'pronoun',
            'prep':'preposition', 'conj':'conjunction'}


def definition(value):
    """Return POS and synonyms without joining list/string fields characterwise."""
    body = plain(value)
    match = _POS.match(body)
    pos = ''
    if match:
        pos = _ALIASES.get(match.group(1).casefold(), match.group(1).casefold())
        body = body[match.end():]
    # Bracketed usage notes do not belong to a synonym. Retain explicit negation.
    def remove_note(match):
        inner = match.group(1)
        if re.search(r'不|未|无|非|\b(?:not|no|never)\b', inner, re.I):
            return inner
        return ''
    for _ in range(8):
        updated = re.sub(r'\(([^()]*)\)', remove_note, body)
        if updated == body:
            break
        body = updated
    return pos, body


def definition_parts(value):
    _, body = definition(value)
    return {sentence_key(p) for p in re.split(r'[;；，,、]', body) if sentence_key(p)}


def example_records(value):
    if isinstance(value, dict):
        if value.get('sen_content'):
            yield value
        for child in value.values():
            if isinstance(child, (dict, list)):
                yield from example_records(child)
    elif isinstance(value, list):
        for child in value:
            yield from example_records(child)


def senses(data):
    if not isinstance(data, dict):
        return
    for item in data.get('means') or []:
        if isinstance(item, dict):
            yield plain(item.get('mean')), list(example_records(item))
    for item in data.get('options') or []:
        if not isinstance(item, dict):
            continue
        content = item.get('content')
        if isinstance(content, dict):
            yield plain(content.get('mean')), list(example_records(content))


def context_definitions(exam, data):
    stem = exam.get('stem') or {}
    en, zh = sentence_key(stem.get('content')), sentence_key(stem.get('remark'))
    found = []
    for meaning, examples in senses(data):
        if any((en and sentence_key(e.get('sen_content')) == en) or
               (zh and sentence_key(e.get('sen_mean_cn')) == zh) for e in examples):
            if meaning and meaning not in found:
                found.append(meaning)
    return found


def resolve_word(word, known_words, lemmatize):
    """Resolve inflections against actual course words before using the local NLP model."""
    word = plain(word)
    normalized = word.casefold()
    known = {plain(w).casefold(): plain(w) for w in known_words if isinstance(w, str)}
    if normalized in known:
        return known[normalized]
    candidates = set()
    if normalized.endswith('ies') and len(normalized) > 3:
        candidates.add(normalized[:-3] + 'y')
    for ending in ('ing', 'ed', 'es', 's'):
        if normalized.endswith(ending) and len(normalized) > len(ending) + 1:
            root = normalized[:-len(ending)]
            candidates.update((root, root + 'e'))
            if len(root) > 1 and root[-1] == root[-2]:
                candidates.add(root[:-1])
    matches = candidates & known.keys()
    if len(matches) == 1:
        return known[next(iter(matches))]
    lemma = plain(lemmatize(word))
    return known.get(lemma.casefold(), lemma or word)
