"""Per-user encrypted API credentials and model settings. CiXu modification 2026-10-19."""
import base64
import ctypes
from ctypes import wintypes
import json
from pathlib import Path
import os

DEFAULTS = {'mode':'off','base_url':'https://ark.cn-beijing.volces.com/api/v3',
            'model':'','confidence':0.8,'timeout':30,'allow_definition_images':False}


class Blob(ctypes.Structure):
    _fields_=[('size',wintypes.DWORD),('data',ctypes.POINTER(ctypes.c_ubyte))]


def _crypt(raw, decrypt=False):
    buffer=ctypes.create_string_buffer(raw)
    source=Blob(len(raw),ctypes.cast(buffer,ctypes.POINTER(ctypes.c_ubyte)))
    target=Blob()
    crypt=ctypes.windll.crypt32
    # UI_FORBIDDEN; data is tied to the currently logged-in Windows user.
    if decrypt:
        ok=crypt.CryptUnprotectData(ctypes.byref(source),None,None,None,None,1,ctypes.byref(target))
    else:
        ok=crypt.CryptProtectData(ctypes.byref(source),'CiXu model API key',None,None,None,1,ctypes.byref(target))
    if not ok: raise OSError('Windows 无法处理 API Key 的本地加密。')
    try: return ctypes.string_at(target.data,target.size)
    finally:
        free=ctypes.windll.kernel32.LocalFree
        free.argtypes=[ctypes.c_void_p]; free.restype=ctypes.c_void_p
        free(ctypes.cast(target.data,ctypes.c_void_p))


def load(root):
    config=dict(DEFAULTS)
    try:
        data=json.loads((Path(root)/'config'/'model_assist.json').read_text(encoding='utf-8'))
        config.update({k:data[k] for k in DEFAULTS if k in data})
        if data.get('key_protected'):
            config['api_key']=_crypt(base64.b64decode(data['key_protected']),True).decode('utf-8')
    except (OSError,ValueError,KeyError):
        config['credential_error']=True
    config.setdefault('api_key','')
    from util.privacy import register_secret
    register_secret(config['api_key'])
    return config


def save(root,config):
    mode=config.get('mode','off')
    if mode not in ('off','api','manual'): raise ValueError('无法识别的辅助方式。')
    data={k:config.get(k,v) for k,v in DEFAULTS.items()}
    data['confidence']=min(1,max(0,float(data['confidence'])))
    data['timeout']=min(90,max(5,int(data['timeout'])))
    if config.get('api_key'):
        data['key_protected']=base64.b64encode(_crypt(config['api_key'].encode('utf-8'))).decode('ascii')
    path=Path(root)/'config'/'model_assist.json'; path.parent.mkdir(parents=True,exist_ok=True)
    temporary=path.with_suffix('.tmp')
    temporary.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
    os.replace(temporary,path)
    return {**data,'api_key':config.get('api_key','')}
