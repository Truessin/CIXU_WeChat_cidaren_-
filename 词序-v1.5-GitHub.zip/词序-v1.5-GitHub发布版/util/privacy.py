"""Best-effort protection for diagnostic output, not a substitute for review."""
import logging
import re

_secrets = set()


def register_secret(value):
    if isinstance(value, str) and len(value) >= 4:
        _secrets.add(value)


def redact(value):
    text = str(value)
    for secret in sorted(_secrets, key=len, reverse=True):
        text = text.replace(secret, '[REDACTED]')
    text = re.sub(r'sk-[A-Za-z0-9_-]{12,}', '[REDACTED]', text)
    text = re.sub(
        r'''(?i)(["']?(?:user_?token|access_?token|api_?key|key_protected|password|passwd|secret|private_key|database_url|authorization|cookie|topic_code)["']?\s*[:=]\s*)(?:"[^"\n]*"|'[^'\n]*'|[^\s,}\n]+)''',
        r'\1[REDACTED]', text)
    text = re.sub(r'(?i)Bearer\s+[^\s\'",}]+', 'Bearer [REDACTED]', text)
    text = re.sub(r'(?i)[A-Z]:[\\/]+Users[\\/]+[^\\/\s\'"<>]+', '<USER_HOME>', text)
    return text


class PrivacyFormatter(logging.Formatter):
    def format(self, record):
        # Format first: this also sanitizes interpolation arguments and traceback.
        return redact(super().format(record))
