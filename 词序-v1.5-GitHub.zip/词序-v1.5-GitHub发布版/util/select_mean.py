import random
import re
import unicodedata

from api.main_api import query_word
from log.log import Log
from util.word_revert import word_revert
from util.local_language import (plain, definition, definition_parts,
                                 sentence_key, example_records, senses, resolve_word)

# log module
select_module = Log("select_mean")


#
def handle_query_word_mean(public_info) -> None:
    # {'course_id': 'CET4_pre', 'list_id': 'CET4_pre_03', 'word': 'pack', 'update_version': '2402041319', 'means': [{'mean': ['verb', '收拾（行李）；装（箱）'], 'ph_info': {'ph_en': 'pæk', 'ph_en_url': '/Resource/unitAudio_EN/CET4_pre_03/pack.mp3', 'ph_us': 'pæk', 'ph_us_url': '/Resource/unitAudio_US/CET4_pre_03/pack.mp3'}, 'usages': [{'usage': None, 'phrases': [], 'phrases_infos': [], 'examples': [{'sen_id': '688', 'sen_content': "Mary, I hope you're {packed} and ready to leave.", 'sen_mean_cn': '玛丽，我希望你收拾好行李准备离开。', 'sen_source': '[CET4 07年12月]', 'sen_source_code': 'CET4_0712_LL1_1M_1', 'audio_file': '/CET4_pre_03/pack/688.mp3'}, {'sen_id': '695', 'sen_content': "I've {packed} it, but I can't remember which bag it's in.", 'sen_mean_cn': '我把它装好了，但我记不起它在哪个包里了。', 'sen_source': '[CET4 07年12月]', 'sen_source_code': 'CET4_0712_LL1_4W_3', 'audio_file': '/CET4_pre_03/pack/695.mp3'}, {'sen_id': '562846', 'sen_content': 'We can {pack} a suitcase with flashlights, a radio, food, drinking water and some tools.', 'sen_mean_cn': '我们可以把手电筒、收音机、食物、饮用水和一些工具打包装入手提箱。', 'sen_source': '[CET6 13年06月]', 'sen_source_code': 'CET6_13063_LP2_1_5_01', 'audio_file': '/CET4_pre_03/pack/562846.mp3'}, {'sen_id': '521628', 'sen_content': 'She hurriedly {packed} a bag and bought a train ticket for home.', 'sen_mean_cn': '她赶快收拾了一下手提包，买了车票回家。', 'sen_source': '', 'sen_source_code': '', 'audio_file': '/CET4_pre_03/pack/521628.mp3'}, {'sen_id': '521637', 'sen_content': 'She {packed} her few belongings in a bag and left.', 'sen_mean_cn': '她把她的几件东西装进包里便离开了。', 'sen_source': '', 'sen_source_code': '', 'audio_file': '/CET4_pre_03/pack/521637.mp3'}]}]}, {'mean': ['noun', '包；盒'], 'ph_info': {'ph_en': 'pæk', 'ph_en_url': '/Resource/unitAudio_EN/CET4_pre_03/pack.mp3', 'ph_us': 'pæk', 'ph_us_url': '/Resource/unitAudio_US/CET4_pre_03/pack.mp3'}, 'usages': [{'usage': None, 'phrases': [], 'phrases_infos': [], 'examples': [{'sen_id': '2185', 'sen_content': "Likewise, a married man who smokes more than a {pack} a day is likely to live as long as a divorced man who doesn't smoke.", 'sen_mean_cn': '同样地，一个每天吸烟超过一包的已婚男人很可能和一个不吸烟的离婚男人一样长寿。', 'sen_source': '[CET4 10年12月]', 'sen_source_code': 'CET4_1012_RP2_02_03', 'audio_file': '/CET4_pre_03/pack/2185.mp3'}, {'sen_id': '521639', 'sen_content': 'Each {pack} contains a book and accompanying CD.', 'sen_mean_cn': '每包内装书一本，并附光盘一张。', 'sen_source': '', 'sen_source_code': '', 'audio_file': '/CET4_pre_03/pack/521639.mp3'}, {'sen_id': '562705', 'sen_content': 'Envelopes are cheaper if you buy them in {packs} of 100.', 'sen_mean_cn': '信封如果按每包100个地成包购买会便宜一些。', 'sen_source': '', 'sen_source_code': '', 'audio_file': '/CET4_pre_03/pack/562705.mp3'}]}, {'usage': {'marked': 'a {pack} of <i>sth</i> ', 'text': 'a pack of sth ', 'cn': '一包/盒…', 'eg': 'a {pack} of cigarettes', 'eg_cn': ''}, 'phrases': ['a {pack} of … 一包……'], 'phrases_infos': [{'sen_id': '156901', 'sen_content': 'a {pack} of …', 'sen_mean_cn': '一包……', 'audio_file': '/CET4_pre_03/pack/156901.mp3'}], 'examples': [{'sen_id': '477487', 'sen_content': 'He reached into a drawer for a {pack} of cigarettes.', 'sen_mean_cn': '他把手伸进抽屉里，掏出一包香烟。', 'sen_source': '', 'sen_source_code': '', 'audio_file': '/CET4_pre_03/pack/477487.mp3'}]}]}], 'version': '2', 'has_au': 1, 'au_addr': 'https://resource-cdn.vocabgo.com', 'au_word': 'pack', 'word_info': {'store_status': 0}}
    means = []
    if public_info.word_query_result.get('options'):
        # {'course_id': 'XSJ_4', 'list_id': 'XSJ_4_7_A', 'word': 'detached', 'update_version': '2402041319', 'ph_en': 'dɪˈtætʃt', 'ph_us': 'dɪˈtætʃt', 'options': [{'content': {'mean': 'adj  超然的；冷漠的', 'ph_info': {'ph_en': 'dɪˈtætʃt', 'ph_en_url': '/Resource/unitAudio_EN/XSJ_4_7_A/detached.mp3', 'ph_us': 'dɪˈtætʃt', 'ph_us_url': '/Resource/unitAudio_US/XSJ_4_7_A/detached.mp3'}, 'usage_infos': [{'sen_id': '83415', 'sen_content': '{detached} observer', 'sen_mean_cn': '超然的旁观者', 'audio_file': '/XSJ_4_7_A/detached/83415.mp3'}, {'sen_id': '83416', 'sen_content': '{detached} attitude', 'sen_mean_cn': '超然的态度', 'audio_file': '/XSJ_4_7_A/detached/83416.mp3'}], 'usage': ['{detached} observer 超然的旁观者', '{detached} attitude 超然的态度'], 'example': [{'sen_id': '150878', 'sen_content': 'She wanted him to stop being so cool, so {detached}.', 'sen_mean_cn': '她希望他不再那么冷酷无情，那么无动于衷。', 'sen_source': '', 'sen_source_code': '', 'audio_file': '/XSJ_4_7_A/detached/150878.mp3'}, {'sen_id': '282590', 'sen_content': 'Through all the arguments among other committee members, she kept a {detached} attitude.', 'sen_mean_cn': '在其他委员会成员辩论时，她始终保持超然的态度。', 'sen_source': '', 'sen_source_code': '', 'audio_file': '/XSJ_4_7_A/detached/282590.mp3'}, {'sen_id': '445016', 'sen_content': 'Throughout the novel, the whole story is seen through the eyes of a {detached} observer.', 'sen_mean_cn': '小说自始至终是从一个超然的旁观者的角度来看整个故事的。', 'sen_source': '', 'sen_source_code': '', 'audio_file': '/XSJ_4_7_A/detached/445016.mp3'}, {'sen_id': '150879', 'sen_content': 'He tries to remain emotionally {detached} from the prisoners, but fails.', 'sen_mean_cn': '他试图不带感情地对待那些犯人，但是做不到。', 'sen_source': '', 'sen_source_code': '', 'audio_file': '/XSJ_4_7_A/detached/150879.mp3'}]}}, {'content': {'mean': 'adj 客观的，公正的', 'ph_info': {'ph_en': 'dɪˈtætʃt', 'ph_en_url': '/Resource/unitAudio_EN/XSJ_4_7_A/detached.mp3', 'ph_us': 'dɪˈtætʃt', 'ph_us_url': '/Resource/unitAudio_US/XSJ_4_7_A/detached.mp3'}, 'usage_infos': [{'sen_id': '89188', 'sen_content': '{detached} evaluation', 'sen_mean_cn': '客观公正的评估', 'audio_file': '/XSJ_4_7_A/detached/89188.mp3'}, {'sen_id': '89189', 'sen_content': 'take a {detached} view', 'sen_mean_cn': '采用公正客观的视角', 'audio_file': '/XSJ_4_7_A/detached/89189.mp3'}], 'usage': ['{detached} evaluation 客观公正的评估', 'take a {detached} view 采用公正客观的视角'], 'example': [{'sen_id': '150929', 'sen_content': 'As a judge, he has always been {detached} in dealing with cases.', 'sen_mean_cn': '作为法官，他在处理案件时总是客观公正的。', 'sen_source': '', 'sen_source_code': '', 'audio_file': '/XSJ_4_7_A/detached/150929.mp3'}, {'sen_id': '150922', 'sen_content': 'Evaluation of public servants shall be {detached}.', 'sen_mean_cn': '对公务员的考核应当客观公正。', 'sen_source': '', 'sen_source_code': '', 'audio_file': '/XSJ_4_7_A/detached/150922.mp3'}, {'sen_id': '150915', 'sen_content': 'A judge must be {detached} when weighing evidence.', 'sen_mean_cn': '法官在掂量证据时应该客观公正。', 'sen_source': '', 'sen_source_code': '', 'audio_file': '/XSJ_4_7_A/detached/150915.mp3'}]}}], 'version': '1', 'has_au': 1, 'au_addr': 'https://resource-cdn.vocabgo.com', 'au_word': 'detached', 'word_info': {'store_status': 0}}
        for mean in public_info.word_query_result['options']:
            means.append(plain(mean['content']['mean']))
    else:
        for mean in public_info.word_query_result['means']:
            means.append(plain(mean['mean']))
            # means.append(re.sub("（.*）", "", mean['content']['mean']))
    select_module.logger.info(f"提取到正确选项：{means}")
    public_info.word_means = means


# extract options
def filler_option(public_info) -> list:
    """
    提取题目中返回的选项以及排序优化
    :param public_info:
    :return:
    """
    # 试题选项
    options = []
    source = []
    # 填充选项
    for option_info in public_info.exam["options"]:
        option = option_info['content']
        source.append(option)
        if option in public_info.word_list:
            options.insert(0, option)
        else:
            options.append(option)
    public_info.source_option = source
    select_module.logger.info(f"提取到题目选项{options}")
    return options


def _strip_pos(text):
    return definition(text)[1]


def _normalize_mean(text):
    return sentence_key(_strip_pos(text))


def _mean_parts(text):
    return definition_parts(text)


def _meaning_score(option, meanings):
    normalized = _normalize_mean(option)
    if not normalized: return 0
    scores = []
    for meaning in meanings:
        option_pos, _ = definition(option)
        meaning_pos, _ = definition(meaning)
        if option_pos and meaning_pos and option_pos != meaning_pos:
            continue
        if normalized == _normalize_mean(meaning): scores.append(100)
        elif _mean_parts(option) == _mean_parts(meaning) and _mean_parts(option): scores.append(98)
        elif _mean_parts(option) & _mean_parts(meaning): scores.append(90)
    return max(scores, default=0)


def _unique_mean_option(options, meanings):
    scored = [(i, option, _meaning_score(option.get('content', ''), meanings))
              for i, option in enumerate(options)]
    best = max((score for _, _, score in scored), default=0)
    matches = [(i, option) for i, option, score in scored if score == best and score > 0]
    if len(matches) == 1:
        i, option = matches[0]
        return option.get('answer_tag', i)
    return None


def select_mean(public_info):
    """Keep original option tags and decline ambiguous definitions."""
    return _unique_mean_option(public_info.exam.get('options') or [], public_info.word_means)


def select_match_word(public_info, word_mean):
    matches = []
    for i, option in enumerate(public_info.exam.get('options') or []):
        query_word(public_info, option['content'])
        handle_query_word_mean(public_info)
        if _meaning_score(word_mean, public_info.word_means):
            matches.append(option.get('answer_tag', i))
    return matches[0] if len(matches) == 1 else None


def is_word_exist(public_info, option) -> bool:
    """
    word是否存在word_list中
    :param public_info:
    :param option: word
    :return: None
    """
    normalized = resolve_word(option, public_info.word_list, word_revert)
    if normalized in {plain(w) for w in public_info.word_list}:
        query_word(public_info, normalized)
        return True
    else:
        return False


# extract sentence word
def _sentence_norm(value):
    return sentence_key(value)


def _example_records(data):
    yield from example_records(data)


def word_examples(public_info, options):
    stem = public_info.exam.get('stem') or {}
    target = _sentence_norm(stem.get('remark'))
    template = plain(stem.get('content'))
    has_blank = len(re.findall(r'\{[^{}]*\}', template)) == 1
    if not target and not has_blank: return ''
    matches = set()
    for word in dict.fromkeys(options):
        if is_word_exist(public_info, word):
            for example in _example_records(public_info.word_query_result):
                content = plain(example.get('sen_content'))
                words = re.findall(r'{([^{}]+)}', content)
                if len(words) != 1:
                    continue
                answer = words[0]
                same_zh = bool(target and _sentence_norm(example.get('sen_mean_cn')) == target)
                same_en = bool(has_blank and _sentence_norm(re.sub(r'\{[^{}]*\}', lambda _: answer, template)) == _sentence_norm(content))
                if same_en or (same_zh and not has_blank):
                    matches.add(answer)
    return next(iter(matches)) if len(matches) == 1 else ''
