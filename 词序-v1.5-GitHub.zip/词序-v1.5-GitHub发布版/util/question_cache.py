"""Verified answers keyed by full question, independent of shuffled option tags."""
import hashlib
import json
import os
import threading
from pathlib import Path
import html
import re
import unicodedata

_lock = threading.RLock()


def _format_text(value):
    if isinstance(value, str):
        text = unicodedata.normalize('NFKC', html.unescape(value))
        return re.sub(r'\s+', ' ', text).strip()
    if isinstance(value, list): return [_format_text(v) for v in value]
    if isinstance(value, dict): return {k:_format_text(v) for k,v in value.items()}
    return value


def key_for(exam, normalized=True):
    normalize = _format_text if normalized else lambda x:x
    options = sorted(json.dumps(normalize(o.get('content')), ensure_ascii=False, sort_keys=True)
                     for o in exam.get('options', []) if isinstance(o, dict))
    content = {k: normalize(exam.get(k)) for k in ('topic_mode', 'w_tip', 'w_lens', 'tips')}
    stem = exam.get('stem') or {}
    content['stem'] = {k: normalize(stem.get(k)) for k in ('content', 'remark')}
    content['options'] = options
    raw = json.dumps(content, ensure_ascii=False, sort_keys=True, separators=(',', ':'))
    return hashlib.sha256(raw.encode('utf-8')).hexdigest()


def _path(info):
    return Path(info.path) / 'config' / 'verified_answers.json'


def _read(info):
    try:
        return json.loads(_path(info).read_text(encoding='utf-8'))
    except (OSError, ValueError):
        return {}


def lookup(info):
    exam = info.exam
    with _lock:
        data = _read(info)
        entry = data.get(key_for(exam)) or data.get(key_for(exam, normalized=False))
    if not isinstance(entry, dict) or entry.get('kind') not in ('text', 'option') or 'value' not in entry:
        return None
    if entry['kind'] == 'text':
        return entry['value']
    matches = [(i, o) for i, o in enumerate(exam.get('options', []))
               if _format_text(o.get('content')) == _format_text(entry['value'])]
    if len(matches) == 1:
        i, option = matches[0]
        return option.get('answer_tag', i)
    return None


def remember(info, answer, correct):
    exam = info.exam
    if not isinstance(exam, dict) or exam.get('topic_mode') in (0, 31):
        return
    with _lock:
        data = _read(info)
        key = key_for(exam)
        if not correct:
            data.pop(key, None)
            data.pop(key_for(exam, normalized=False), None)
        else:
            # Multi-part option tags need their own representation; do not cache them.
            matches = [(i, o) for i, o in enumerate(exam.get('options', []))
                       if o.get('answer_tag', i) == answer]
            if len(matches) == 1:
                data[key] = {'kind':'option', 'value':matches[0][1].get('content')}
            elif exam.get('topic_mode') in (32, 51, 52, 53, 54, 73) and isinstance(answer, str):
                data[key] = {'kind':'text', 'value':answer}
            else:
                return
        path = _path(info); path.parent.mkdir(parents=True, exist_ok=True)
        temporary = path.with_suffix('.tmp')
        temporary.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')
        os.replace(temporary, path)
